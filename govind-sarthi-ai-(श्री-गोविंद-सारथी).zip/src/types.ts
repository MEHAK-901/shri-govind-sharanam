export type ReflectionMode = 'deep-reflection' | 'reflection' | 'brainstorm' | 'summary';

export interface SanskritShloka {
  id: string;
  name: string;
  sanskrit: string;
  translation?: string;
}

export interface GardenSticker {
  id: string;
  emoji: string;
  name: string;
  meaning: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  modelUsed?: string;
  shloka?: SanskritShloka;
  sticker?: GardenSticker;
}

export interface JournalInteraction {
  id: string;
  userId: string;
  title: string;
  reflectionType: ReflectionMode;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessage[];
  summary?: string;
  moodTag?: string;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

export interface ThreatZoneCountermeasure {
  zone: 'Input Surfaces' | 'Planning & Reasoning' | 'Tool Execution' | 'Memory & State' | 'Inter-System Communication';
  threatDescription: string;
  owaspReference: string;
  countermeasureImplemented: string;
  status: 'Enforced' | 'Active';
}
