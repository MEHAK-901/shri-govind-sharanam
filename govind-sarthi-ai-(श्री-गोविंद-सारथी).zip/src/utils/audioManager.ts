import type { SanskritShloka } from '../types';

export class GovindAudioManager {
  private synth: SpeechSynthesis | null = typeof window !== 'undefined' ? window.speechSynthesis : null;
  private voice: SpeechSynthesisVoice | null = null;
  private isMuted: boolean = false;
  private isAmbientPlaying: boolean = false;

  // Web Audio Context for divine Vrindavan flute & tanpura
  private audioCtx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private tanpuraGain: GainNode | null = null;
  private fluteGain: GainNode | null = null;
  private reverbNode: ConvolverNode | DelayNode | null = null;
  private melodyTimer: any = null;
  private tanpuraTimer: any = null;

  // Voice playback state - Subtle & Empathic Mahabharat Audio Play Engine
  private isSpeaking: boolean = false;
  private activeSpeakingId: string | null = null;
  private fluteVolume: number = 0.10; // Softer, ear-friendly ambient volume (no ear strain)
  private voiceVolume: number = 0.38; // Clear, warm vocal volume
  private autoSpeakEnabled: boolean = false; // Default false so voice never startles!
  private speechQueueIndex: number = 0;
  private currentSpeechSessionId: number = 0;
  private speechPauseTimer: any = null;

  public readonly AMBIENT_DEFAULT_VOL = 0.10;
  public readonly AMBIENT_DUCKED_VOL = 0.02;

  public shlokas: SanskritShloka[] = [
    {
      id: 'gita_2_47',
      name: 'Karmanye Vadhikaraste',
      sanskrit: 'Karmanye vadhikaraste ma phaleshu kadachana | Ma karmaphalahetur bhurma te sango stvakarmani ||',
      translation: 'You have a right only to perform your duty, never to its fruits. Let not results be your motive.'
    },
    {
      id: 'shanti_mantra',
      name: 'Sarve Bhavantu Sukhinah',
      sanskrit: 'Om Sarve bhavantu sukhinah sarve santu niramayah | Sarve bhadrani pashyantu ma kashchid duhkha-bhag bhavet ||',
      translation: 'May all beings be peaceful and happy, may all be healthy, may no one suffer.'
    },
    {
      id: 'gita_4_7',
      name: 'Yada Yada Hi Dharmasya',
      sanskrit: 'Yada yada hi dharmasya glanir bhavati bharata | Abhyutthanam adharmasya tadatmanam srijamy aham ||',
      translation: 'Whenever righteousness declines and unrighteousness rises, I manifest to restore balance.'
    },
    {
      id: 'gita_2_63',
      name: 'Krodhad Bhavati Sammohah',
      sanskrit: 'Krodhad bhavati sammohah sammohat smriti-vibhramah | Smriti-bhramshad buddhi-nasho buddhi-nashat pranashyati ||',
      translation: 'From anger arises bewilderment, leading to loss of memory, intellect ruin, and downfall.'
    },
    {
      id: 'vasudhaiva',
      name: 'Vasudhaiva Kutumbakam',
      sanskrit: 'Ayam nijah paro vetti ganana laghuchetasam | Udara-charitanam tu vasudhaiva kutumbakam ||',
      translation: 'Only the narrow-minded calculate mine vs thine. For the noble-hearted, the earth is one family.'
    }
  ];

  constructor() {
    if (typeof window !== 'undefined') {
      this.initVoice();
      this.bindVisibilityHandler();
    }
  }

  /**
   * Intelligently selects the most soothing, empathic, and warm natural voice available
   * Filtering out harsh, robotic, or metallic synthesizers
   */
  private initVoice() {
    if (!this.synth) return;
    const loadVoices = () => {
      const voices = this.synth?.getVoices() || [];
      if (!voices.length) return;

      // Priority ladder for gentle, soulful, articulate human-sounding voices
      const preferredVoice =
        voices.find((v) => v.name.includes('Google UK English Male') || v.name.includes('George')) ||
        voices.find((v) => (v.lang.includes('en-IN') || v.lang.includes('hi-IN')) && !v.name.includes('eSpeak') && !v.name.includes('Desktop')) ||
        voices.find((v) => v.name.includes('Natural') || v.name.includes('Online')) ||
        voices.find((v) => v.name.includes('Daniel') || v.name.includes('Arthur') || v.name.includes('Oliver')) ||
        voices.find((v) => v.lang.includes('en-GB')) ||
        voices.find((v) => v.lang.includes('en-US')) ||
        voices[0];

      this.voice = preferredVoice || null;
    };

    loadVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }

  private bindVisibilityHandler() {
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (this.isAmbientPlaying) {
          this.pauseAmbientDrone();
        }
      } else {
        if (this.isAmbientPlaying && !this.isMuted) {
          this.resumeAmbientDrone();
        }
      }
    });
  }

  /**
   * Divine Vrindavan Flute & Tanpura Audio Engine
   * Reference: RadhaKrishn Flute (mGC-S7n_HkE & MmOAsC7A39o)
   * Physics-modeled acoustic bamboo bansuri:
   * 1. Resonant breath chiff (shaped noise component across the embouchure blowhole)
   * 2. Fundamental cylindrical bamboo tone with natural 2nd & 3rd harmonics
   * 3. Authentic Indian legato meend (continuous pitch gliding between swaras)
   * 4. Devotional finger gamak (kampan vibrato that blossoms on held notes)
   * 5. Vrindavan temple acoustic reverb & spatial stereo reflection network
   */
  private initWebAudioDrone() {
    if (this.audioCtx) return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    this.audioCtx = new AudioContextClass();

    // Master gain
    this.masterGain = this.audioCtx.createGain();
    this.masterGain.gain.setValueAtTime(this.fluteVolume, this.audioCtx.currentTime);

    // Ultra-smooth, velvet lowpass filter (removes piercing ear-strain frequencies > 780 Hz)
    const masterFilter = this.audioCtx.createBiquadFilter();
    masterFilter.type = 'lowpass';
    masterFilter.frequency.setValueAtTime(780, this.audioCtx.currentTime);
    masterFilter.Q.setValueAtTime(0.7, this.audioCtx.currentTime); // gentle Bessel curve, no resonant peak

    // Sacred Temple Reverb & Spatial Delay (simulates ancient Yamuna marble temple)
    const delay1 = this.audioCtx.createDelay();
    delay1.delayTime.setValueAtTime(0.35, this.audioCtx.currentTime);

    const delay2 = this.audioCtx.createDelay();
    delay2.delayTime.setValueAtTime(0.52, this.audioCtx.currentTime);

    const feedbackGain = this.audioCtx.createGain();
    feedbackGain.gain.setValueAtTime(0.24, this.audioCtx.currentTime);

    const delayFilter = this.audioCtx.createBiquadFilter();
    delayFilter.type = 'lowpass';
    delayFilter.frequency.setValueAtTime(650, this.audioCtx.currentTime);

    delay1.connect(delayFilter);
    delayFilter.connect(feedbackGain);
    feedbackGain.connect(delay2);
    delay2.connect(delay1);

    // Flute Bus
    this.fluteGain = this.audioCtx.createGain();
    this.fluteGain.gain.setValueAtTime(0.75, this.audioCtx.currentTime);

    // Warm wooden bamboo body resonance (subtle lower midrange warmth at 380Hz)
    const bambooResonance = this.audioCtx.createBiquadFilter();
    bambooResonance.type = 'peaking';
    bambooResonance.frequency.setValueAtTime(380, this.audioCtx.currentTime);
    bambooResonance.gain.setValueAtTime(1.8, this.audioCtx.currentTime);
    bambooResonance.Q.setValueAtTime(0.8, this.audioCtx.currentTime);

    this.fluteGain.connect(bambooResonance);
    bambooResonance.connect(this.masterGain);
    bambooResonance.connect(delay1);
    delay1.connect(this.masterGain);
    delay2.connect(this.masterGain);

    // Tanpura Bus (sacred drone in pure fifths, soothing soft level)
    this.tanpuraGain = this.audioCtx.createGain();
    this.tanpuraGain.gain.setValueAtTime(0.16, this.audioCtx.currentTime);
    this.tanpuraGain.connect(this.masterGain);

    this.masterGain.connect(masterFilter);
    masterFilter.connect(this.audioCtx.destination);

    // Start flute themes and tanpura loop
    this.startMelodicFluteLoop();
    this.startSoftTanpuraLoop();
  }

  /**
   * Plays a velvety, continuous Krishna flute phrase with authentic legato meend
   * and soft breath chiff modeling (strictly ear-safe, warm fundamental)
   */
  private playFluentFlutePhrase(
    notes: Array<{ f: number; duration: number; meend?: boolean; flourish?: boolean }>,
    onPhraseComplete: () => void
  ) {
    if (!this.audioCtx || !this.fluteGain || this.audioCtx.state !== 'running') {
      onPhraseComplete();
      return;
    }

    try {
      const now = this.audioCtx.currentTime;
      const ctx = this.audioCtx;

      // 1. Fundamental bamboo cylindrical air column (pure sine - dominant, silky)
      const fundamentalOsc = ctx.createOscillator();
      fundamentalOsc.type = 'sine';

      // 2. Warm 2nd harmonic (octave warm body - triangle at very subtle gain)
      const harmonicOsc = ctx.createOscillator();
      harmonicOsc.type = 'triangle';

      // 3. Subtle 3rd harmonic (hollow wood overtone - sine at trace gain)
      const thirdHarmonicOsc = ctx.createOscillator();
      thirdHarmonicOsc.type = 'sine';

      // 4. Soft bamboo breath chiff (whisper quiet noise, never harsh)
      const bufferSize = ctx.sampleRate * 0.15;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.015;
      }
      const breathNoise = ctx.createBufferSource();
      breathNoise.buffer = noiseBuffer;
      breathNoise.loop = true;

      const breathFilter = ctx.createBiquadFilter();
      breathFilter.type = 'bandpass';
      breathFilter.frequency.setValueAtTime(Math.min(notes[0].f * 1.3, 750), now);
      breathFilter.Q.setValueAtTime(2.0, now);

      const breathGain = ctx.createGain();
      breathGain.gain.setValueAtTime(0.0005, now);
      breathNoise.connect(breathFilter);
      breathFilter.connect(breathGain);

      // 5. Natural finger kampan (delicate, slow vibrato LFO at 3.8 Hz)
      const vibratoLfo = ctx.createOscillator();
      vibratoLfo.type = 'sine';
      vibratoLfo.frequency.setValueAtTime(3.8, now);

      const vibratoDepth = ctx.createGain();
      vibratoDepth.gain.setValueAtTime(0, now);

      vibratoLfo.connect(vibratoDepth);
      vibratoDepth.connect(fundamentalOsc.frequency);
      vibratoDepth.connect(harmonicOsc.frequency);
      vibratoDepth.connect(thirdHarmonicOsc.frequency);

      // Phrase envelope
      const phraseGain = ctx.createGain();
      phraseGain.gain.setValueAtTime(0.0001, now);

      // Trace harmonics for authentic warmth without high-frequency shrillness
      const harmonicGain = ctx.createGain();
      harmonicGain.gain.setValueAtTime(0.045, now);

      const thirdGain = ctx.createGain();
      thirdGain.gain.setValueAtTime(0.010, now);

      fundamentalOsc.connect(phraseGain);
      harmonicOsc.connect(harmonicGain);
      harmonicGain.connect(phraseGain);
      thirdHarmonicOsc.connect(thirdGain);
      thirdGain.connect(phraseGain);
      breathGain.connect(phraseGain);

      phraseGain.connect(this.fluteGain);

      // Schedule notes with authentic meend glides in soothing mid-octave
      let timeCursor = now;
      const firstNote = notes[0];
      fundamentalOsc.frequency.setValueAtTime(firstNote.f, timeCursor);
      harmonicOsc.frequency.setValueAtTime(firstNote.f * 2, timeCursor);
      thirdHarmonicOsc.frequency.setValueAtTime(firstNote.f * 3, timeCursor);

      // Gentle breath attack (220ms soft gradual swell - no sudden click)
      phraseGain.gain.linearRampToValueAtTime(0.24, timeCursor + 0.22);
      breathGain.gain.linearRampToValueAtTime(0.012, timeCursor + 0.18);
      breathGain.gain.linearRampToValueAtTime(0.004, timeCursor + 0.35);

      notes.forEach((note, idx) => {
        const nextTime = timeCursor + note.duration;
        const isLast = idx === notes.length - 1;

        // Vibrato swells gracefully and gently on held notes
        if (note.duration > 0.35) {
          vibratoDepth.gain.setValueAtTime(0.2, timeCursor);
          vibratoDepth.gain.linearRampToValueAtTime(1.4, timeCursor + 0.28);
          vibratoDepth.gain.setValueAtTime(1.4, nextTime - 0.08);
          vibratoDepth.gain.linearRampToValueAtTime(0.3, nextTime);
        } else {
          vibratoDepth.gain.setValueAtTime(0.3, timeCursor);
        }

        if (!isLast) {
          const nextNote = notes[idx + 1];
          // Authentic 120ms meend pitch portamento
          fundamentalOsc.frequency.setValueAtTime(note.f, nextTime - 0.12);
          fundamentalOsc.frequency.exponentialRampToValueAtTime(nextNote.f, nextTime);

          harmonicOsc.frequency.setValueAtTime(note.f * 2, nextTime - 0.12);
          harmonicOsc.frequency.exponentialRampToValueAtTime(nextNote.f * 2, nextTime);

          thirdHarmonicOsc.frequency.setValueAtTime(note.f * 3, nextTime - 0.12);
          thirdHarmonicOsc.frequency.exponentialRampToValueAtTime(nextNote.f * 3, nextTime);

          breathFilter.frequency.setValueAtTime(Math.min(nextNote.f * 1.3, 750), nextTime);

          // Subtle natural breath articulation
          if (!note.meend) {
            phraseGain.gain.setValueAtTime(0.24, nextTime - 0.07);
            phraseGain.gain.linearRampToValueAtTime(0.16, nextTime);
            phraseGain.gain.linearRampToValueAtTime(0.24, nextTime + 0.06);
          }
        }

        timeCursor = nextTime;
      });

      // Soulful breath release fade into temple acoustics
      phraseGain.gain.setValueAtTime(0.20, timeCursor - 0.25);
      phraseGain.gain.exponentialRampToValueAtTime(0.0001, timeCursor);
      breathGain.gain.exponentialRampToValueAtTime(0.0001, timeCursor);

      fundamentalOsc.start(now);
      harmonicOsc.start(now);
      thirdHarmonicOsc.start(now);
      breathNoise.start(now);
      vibratoLfo.start(now);

      fundamentalOsc.stop(timeCursor + 0.1);
      harmonicOsc.stop(timeCursor + 0.1);
      thirdHarmonicOsc.stop(timeCursor + 0.1);
      breathNoise.stop(timeCursor + 0.1);
      vibratoLfo.stop(timeCursor + 0.1);

      const totalDurationMs = (timeCursor - now) * 1000;
      setTimeout(() => {
        onPhraseComplete();
      }, totalDurationMs);
    } catch (err) {
      onPhraseComplete();
    }
  }

  /**
   * Iconic Divine Krishna Flute Themes (Tuned to deep, soothing Bansuri in Key of D):
   * Mellow, warm frequencies (196 Hz - 440 Hz). No screechy high notes.
   * 1. RadhaKrishn Opening Theme ("Tum Prem Ho, Radhe Radhe")
   * 2. Vrindavan Yamuna Teere Bansuri Dhun (Sweet soothing twilight prayer)
   * 3. Shri Krishna Govind Hare Murari (Heartfelt prayer melody)
   * 4. Geeta Sarthi Mahabharat Solemn Theme (Dignified wisdom theme)
   * 5. Raag Bhupali Evening Alap (Soothing inner peace)
   */
  private startMelodicFluteLoop() {
    // Soothing Pitch Frequencies in Warm Middle/Lower Register (Raag Yaman & Bhupali)
    const lowPa = 220.00;  // A3 (warm, grounding)
    const lowDha = 246.94; // B3
    const lowNi = 277.18;  // C#4
    const Sa = 293.66;     // D4 (pure sweet center)
    const Re = 329.63;     // E4
    const Ga = 369.99;     // F#4 (mellow warmth)
    const TivraMa = 415.30;// G#4
    const Pa = 440.00;     // A4 (gentle high ceiling)
    const Dha = 493.88;    // B4 (soft accent only)

    const divineKrishnaThemes: Array<Array<{ f: number; duration: number; meend?: boolean }>> = [
      // Theme 1: RadhaKrishn Title Flute Theme ("Tum Prem Ho" - Soft Middle Register)
      [
        { f: Pa, duration: 0.65 },
        { f: Dha, duration: 0.50 },
        { f: Pa, duration: 0.55 },
        { f: TivraMa, duration: 0.50 },
        { f: Ga, duration: 0.55 },
        { f: Re, duration: 0.50 },
        { f: Ga, duration: 1.15, meend: true },
        // Follow-up ascending phrase in warm octave
        { f: Re, duration: 0.45 },
        { f: Ga, duration: 0.50 },
        { f: Pa, duration: 0.55 },
        { f: Dha, duration: 0.60 },
        { f: Pa, duration: 0.85, meend: true },
        { f: Ga, duration: 0.55 },
        { f: Re, duration: 0.55 },
        { f: Sa, duration: 1.50, meend: true },
      ],

      // Theme 2: Vrindavan Yamuna Teere Bansuri Dhun (Sweet evening lullaby)
      [
        { f: Sa, duration: 0.55 },
        { f: Re, duration: 0.50 },
        { f: Ga, duration: 0.60 },
        { f: Pa, duration: 0.75, meend: true },
        { f: Ga, duration: 0.55 },
        { f: Re, duration: 0.50 },
        { f: Sa, duration: 0.85 },
        { f: lowNi, duration: 0.55 },
        { f: lowDha, duration: 0.60 },
        { f: lowPa, duration: 0.95 },
        { f: Sa, duration: 1.45, meend: true },
      ],

      // Theme 3: Shri Krishna Govind Hare Murari (Heartfelt, peaceful devotional)
      [
        { f: Pa, duration: 0.60 },
        { f: Pa, duration: 0.45 },
        { f: Dha, duration: 0.60 },
        { f: Pa, duration: 0.55 },
        { f: TivraMa, duration: 0.50 },
        { f: Ga, duration: 0.70 },
        { f: Re, duration: 0.55 },
        { f: Sa, duration: 0.90, meend: true },
        { f: Re, duration: 0.50 },
        { f: Ga, duration: 1.35, meend: true },
      ],

      // Theme 4: Geeta Sarthi Mahabharat Solemn Theme (Deep, solemn reflection)
      [
        { f: lowPa, duration: 0.65 },
        { f: Sa, duration: 0.70 },
        { f: Re, duration: 0.60 },
        { f: Ga, duration: 0.75 },
        { f: Pa, duration: 0.70 },
        { f: Ga, duration: 0.65 },
        { f: Re, duration: 0.55 },
        { f: Sa, duration: 1.60, meend: true },
      ],

      // Theme 5: Raag Bhupali Evening Twilight Alap (Deep inner peace & stillness)
      [
        { f: Ga, duration: 0.60 },
        { f: Re, duration: 0.55 },
        { f: Sa, duration: 0.90 },
        { f: lowDha, duration: 0.65 },
        { f: lowPa, duration: 1.05 },
        { f: Sa, duration: 0.70 },
        { f: Re, duration: 0.60 },
        { f: Ga, duration: 0.80 },
        { f: Pa, duration: 1.50, meend: true },
      ]
    ];

    let themeIndex = 0;

    const cycleThemes = () => {
      if (!this.isAmbientPlaying || !this.audioCtx || this.audioCtx.state !== 'running') return;

      const currentTheme = divineKrishnaThemes[themeIndex % divineKrishnaThemes.length];
      themeIndex++;

      this.playFluentFlutePhrase(currentTheme, () => {
        if (!this.isAmbientPlaying || !this.audioCtx || this.audioCtx.state !== 'running') return;
        // Extended restful breath pause between flute melodies (3.8 to 5.6 seconds)
        // This ensures the user's ears rest peacefully with just the gentle tanpura drone
        const restfulPause = 3800 + Math.random() * 1800;
        this.melodyTimer = setTimeout(cycleThemes, restfulPause);
      });
    };

    this.melodyTimer = setTimeout(cycleThemes, 400);
  }

  /**
   * Acoustic Tanpura drone in pure fifths (D & A strings)
   */
  private startSoftTanpuraLoop() {
    const pluckTanpuraString = (freq: number) => {
      if (!this.audioCtx || !this.tanpuraGain || this.audioCtx.state !== 'running') return;
      try {
        const now = this.audioCtx.currentTime;
        const osc = this.audioCtx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        const gain = this.audioCtx.createGain();
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.linearRampToValueAtTime(0.055, now + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.8);

        osc.connect(gain);
        gain.connect(this.tanpuraGain);

        osc.start(now);
        osc.stop(now + 3.9);
      } catch (err) {
        // safe catch
      }
    };

    const tanpuraStrings = [146.83, 220.00, 293.66, 146.83];
    let stringIdx = 0;

    const cycleTanpura = () => {
      if (!this.isAmbientPlaying || !this.audioCtx || this.audioCtx.state !== 'running') return;
      pluckTanpuraString(tanpuraStrings[stringIdx % tanpuraStrings.length]);
      stringIdx++;
      this.tanpuraTimer = setTimeout(cycleTanpura, 2800);
    };

    this.tanpuraTimer = setTimeout(cycleTanpura, 250);
  }

  private pauseAmbientDrone() {
    if (this.melodyTimer) clearTimeout(this.melodyTimer);
    if (this.tanpuraTimer) clearTimeout(this.tanpuraTimer);
    if (this.audioCtx && this.audioCtx.state === 'running') {
      this.audioCtx.suspend();
    }
  }

  private resumeAmbientDrone() {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
      this.startMelodicFluteLoop();
      this.startSoftTanpuraLoop();
    }
  }

  public setVolume(volume: number) {
    this.fluteVolume = Math.max(0, Math.min(1, volume));
    if (this.audioCtx && this.masterGain && !this.isSpeaking) {
      this.masterGain.gain.setValueAtTime(this.fluteVolume, this.audioCtx.currentTime);
    }
  }

  public getVolume(): number {
    return this.fluteVolume;
  }

  public setVoiceVolume(vol: number) {
    this.voiceVolume = Math.max(0, Math.min(1, vol));
  }

  public getVoiceVolume(): number {
    return this.voiceVolume;
  }

  public toggleAmbientMusic(): boolean {
    if (this.isAmbientPlaying) {
      this.pauseAmbientDrone();
      this.isAmbientPlaying = false;
      return false;
    } else {
      if (!this.audioCtx) {
        this.initWebAudioDrone();
      } else {
        this.resumeAmbientDrone();
      }
      this.isAmbientPlaying = true;
      this.fadeAmbientVolume(this.fluteVolume, 500);
      return true;
    }
  }

  public fadeAmbientVolume(targetVolume: number, durationMs = 400) {
    if (!this.audioCtx || !this.masterGain) return;
    const now = this.audioCtx.currentTime;
    const target = Math.max(0.001, targetVolume);
    this.masterGain.gain.cancelScheduledValues(now);
    this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, now);
    this.masterGain.gain.exponentialRampToValueAtTime(target, now + durationMs / 1000);
  }

  /**
   * Mahabharat Audio Play Inspired Voice Narration Engine
   * 
   * Captures the legendary dramatic properties of classic Mahabharat audio plays:
   * - Dramatic, pregnant pauses between thoughts and sentences
   * - Dynamic shifting of pitch & cadence based on emotional context:
   *   * Feeling of Loss & Grief (Shok, Virah, Vilap): Deeper, poignant baritone (pitch 0.79, rate 0.72)
   *   * Socratic Inquiry & Self-realization questions: Reflective inquisitive cadence (pitch 0.90, rate 0.76)
   *   * Divine Love, Shelter & Smiling Solace: Warm, luminous reassurance (pitch 0.94, rate 0.78)
   * - Realistic phrase segmentation ensuring the dialogue never rushes
   */
  public speak(
    text: string,
    messageId?: string,
    onStart?: () => void,
    onComplete?: () => void
  ) {
    if (this.isMuted || !this.synth) {
      if (onComplete) onComplete();
      return;
    }

    try {
      this.stopSpeaking(); // Cancel any prior speech cleanly

      const sessionId = ++this.currentSpeechSessionId;

      // Clean text of markdown, asterisks, brackets, and code blocks
      const cleanText = text
        .replace(/\*\*(.*?)\*\*/g, '$1')
        .replace(/\*(.*?)\*/g, '$1')
        .replace(/`{1,3}.*?`{1,3}/gs, '')
        .replace(/\[.*?\]/g, '')
        .replace(/#+/g, '')
        .replace(/([.!?])\s*/g, '$1 ')
        .trim();

      // Segment text into dramatic oratorical phrases & sentences (like audio drama script lines)
      const rawSegments = cleanText.match(/[^.!?\n]+[.!?\n]*/g) || [cleanText];
      const segments = rawSegments
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      if (segments.length === 0) {
        if (onComplete) onComplete();
        return;
      }

      this.isSpeaking = true;
      this.activeSpeakingId = messageId || null;

      // Duck flute background music gently while speaking
      if (this.isAmbientPlaying) {
        this.fadeAmbientVolume(this.AMBIENT_DUCKED_VOL, 400);
      }

      if (onStart) onStart();

      let currentSegmentIdx = 0;

      const playNextSegment = () => {
        if (sessionId !== this.currentSpeechSessionId || !this.isSpeaking || !this.synth) {
          return;
        }

        if (currentSegmentIdx >= segments.length) {
          // Completed full audio play narration
          this.isSpeaking = false;
          this.activeSpeakingId = null;
          if (this.isAmbientPlaying) {
            this.fadeAmbientVolume(this.fluteVolume, 800);
          }
          if (onComplete) onComplete();
          return;
        }

        const segmentText = segments[currentSegmentIdx];
        currentSegmentIdx++;

        const utterance = new SpeechSynthesisUtterance(segmentText);
        if (this.voice) {
          utterance.voice = this.voice;
        }

        // Semantic emotion detection & dynamic pitch/rate calibration (Mahabharat Audio Play Style)
        const lowerSeg = segmentText.toLowerCase();

        const isLossOrGrief =
          /(dard|peeda|kho|virah|ansoo|chhoot|toot|akela|dukh|shok|bichhad|bhasm|vinash|rona|vilap|kasht|maran)/i.test(lowerSeg);

        const isSocraticQuestion =
          /(\?|kya|kyun|kaise|sochiye|socha|vichar|kiska|kaun|parth)/i.test(lowerSeg);

        const isDivineSolaceOrSmile =
          /(muskuraiye|radhe|main hoon|prem|sharan|raksha|dhairya|anand|shanti|sakha|priye|kripa|ashwasan)/i.test(lowerSeg);

        let pauseAfterMs = 380;

        if (isLossOrGrief) {
          // Deep, poignant, sorrowful baritone resonance for grief & loss
          utterance.pitch = 0.79;
          utterance.rate = 0.72;
          pauseAfterMs = 540; // Dramatic heavy pause for grief
        } else if (isSocraticQuestion) {
          // Inquisitive, reflective, soul-searching cadence
          utterance.pitch = 0.90;
          utterance.rate = 0.76;
          pauseAfterMs = 460; // Pregnant pause for seeker to introspect
        } else if (isDivineSolaceOrSmile) {
          // Luminous, warm, tender Krishna reassurance
          utterance.pitch = 0.94;
          utterance.rate = 0.79;
          pauseAfterMs = 360;
        } else {
          // Dignified, steady Mahabharat oratorical baseline
          utterance.pitch = 0.85;
          utterance.rate = 0.77;
          pauseAfterMs = 340;
        }

        utterance.volume = this.voiceVolume;

        utterance.onend = () => {
          if (sessionId !== this.currentSpeechSessionId) return;

          // Natural dramatic pause between lines before proceeding to the next thought
          this.speechPauseTimer = setTimeout(() => {
            playNextSegment();
          }, pauseAfterMs);
        };

        utterance.onerror = (e) => {
          console.warn('Utterance speech warning:', e);
          if (sessionId !== this.currentSpeechSessionId) return;
          // Continue to next segment on recoverable error
          this.speechPauseTimer = setTimeout(() => {
            playNextSegment();
          }, 150);
        };

        this.synth.speak(utterance);
      };

      playNextSegment();
    } catch (err) {
      console.warn('Speech synthesis warning:', err);
      this.isSpeaking = false;
      this.activeSpeakingId = null;
      if (this.isAmbientPlaying) {
        this.fadeAmbientVolume(this.fluteVolume, 400);
      }
      if (onComplete) onComplete();
    }
  }

  public stopSpeaking() {
    this.currentSpeechSessionId++;
    if (this.speechPauseTimer) {
      clearTimeout(this.speechPauseTimer);
      this.speechPauseTimer = null;
    }
    if (this.synth) {
      this.synth.cancel();
    }
    this.isSpeaking = false;
    this.activeSpeakingId = null;
    if (this.isAmbientPlaying) {
      this.fadeAmbientVolume(this.fluteVolume, 500);
    }
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }

  public getActiveSpeakingId(): string | null {
    return this.activeSpeakingId;
  }

  public setAutoSpeakEnabled(enabled: boolean) {
    this.autoSpeakEnabled = enabled;
  }

  public getAutoSpeakEnabled(): boolean {
    return this.autoSpeakEnabled;
  }

  public stopAll() {
    this.pauseAmbientDrone();
    this.isAmbientPlaying = false;
    this.stopSpeaking();
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.isMuted) {
      this.stopSpeaking();
      this.fadeAmbientVolume(0, 300);
    } else {
      if (this.isAmbientPlaying) {
        this.fadeAmbientVolume(this.fluteVolume, 500);
      }
    }
    return this.isMuted;
  }

  public getIsPlaying(): boolean {
    return this.isAmbientPlaying;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }
}

export const govindAudio = new GovindAudioManager();
