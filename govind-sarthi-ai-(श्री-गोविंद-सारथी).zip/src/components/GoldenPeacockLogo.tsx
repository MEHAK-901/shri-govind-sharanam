import React from 'react';
import officialLogoImg from '../assets/images/shri_govind_sharanam_logo.jpg';

interface GoldenPeacockLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const GoldenPeacockLogo: React.FC<GoldenPeacockLogoProps> = ({
  className = '',
  size = 'md',
  showText = false,
}) => {
  const sizeMap = {
    sm: 'h-8 w-8',
    md: 'h-10 w-10',
    lg: 'h-14 w-14',
    xl: 'h-20 w-20',
  };

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      <div
        className={`relative shrink-0 rounded-full overflow-hidden border border-[#B89548]/40 shadow-xs bg-[#17241E] ${sizeMap[size]}`}
      >
        <img
          src={officialLogoImg}
          alt="Shri Govind Sharanam Divine Logo"
          className="w-full h-full object-cover object-center"
          referrerPolicy="no-referrer"
        />
      </div>

      {showText && (
        <div className="flex flex-col text-left leading-tight select-none">
          <span className="font-serif text-sm sm:text-base font-semibold text-[#203D32] tracking-wide">
            Shri Govind
          </span>
          <span className="font-serif text-xs sm:text-sm font-normal text-[#B89548] tracking-widest uppercase">
            Sharanam
          </span>
        </div>
      )}
    </div>
  );
};

