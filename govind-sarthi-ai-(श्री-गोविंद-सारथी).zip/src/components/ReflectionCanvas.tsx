import React, { useState, useRef, useEffect } from 'react';
import { 
  Compass, 
  Sparkles, 
  Lightbulb, 
  FileText, 
  Copy, 
  Check, 
  AlertCircle, 
  RefreshCw, 
  BookmarkCheck, 
  Clock, 
  Volume2,
  VolumeX,
  X,
  ChevronRight
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { GoldenPeacockLogo } from './GoldenPeacockLogo';
import { govindAudio } from '../utils/audioManager';
import type { JournalInteraction, ChatMessage, ReflectionMode, GardenSticker } from '../types';

interface ReflectionCanvasProps {
  interaction: JournalInteraction;
  onUpdateInteraction: (updated: JournalInteraction, shouldSaveToDb?: boolean) => Promise<void>;
  onGenerateSummary: () => Promise<void>;
  isGeneratingAI: boolean;
  saveStatus: 'idle' | 'saving' | 'saved' | 'error';
  saveError: string | null;
  onRetrySave: () => void;
}

export const VRINDAVAN_GARDEN_STICKERS: GardenSticker[] = [
  { id: 'lotus', emoji: '🪷', name: 'Padma', meaning: 'Anaasakti va pavitrata' },
  { id: 'peacock', emoji: '🦚', name: 'Mor Pankh', meaning: 'Govind ka mukut va divya drishti' },
  { id: 'tulsi', emoji: '🌿', name: 'Tulsi Dal', meaning: 'Nishkama samarpan' },
  { id: 'bansuri', emoji: '🪈', name: 'Bansuri', meaning: 'Antaratma ki shanti' },
];

const CONTEMPLATION_QUESTIONS = [
  { 
    label: 'Dard & Virah (Feeling of Loss)', 
    text: 'Hey Govind... jab kisi priya vyakti ya sthiti ke chhoot jaane se hriday mein gehari peeda aur akelepan ka shok uthe, toh is dukh ko aatma kaise sahe?' 
  },
  { 
    label: 'Krodh & Apmaan (Anger & Ego)', 
    text: 'Hey Sarthi... jab koi mera anuchit tiraskaar kare aur man mein krodh ki aag bhadak uthe, toh aatm-samman aur ahankaar ka antar kaise samjhoon?' 
  },
  { 
    label: 'Moh vs Kartavya (Duty vs Attachment)', 
    text: 'Hey Krishna... jab apno ke moh aur satya ke kartavya ke beech yuddh chhid jaye, toh manushya ko kiska chayan karna chahiye?' 
  },
  { 
    label: 'Bhavishya ka Bhay (Fear & Anxiety)', 
    text: 'Govind... jab charo taraf andhera lage aur bhavishya ki chinta man ko gher le, toh sharanagati aur dhairya kaise dharan karein?' 
  },
];

export const ReflectionCanvas: React.FC<ReflectionCanvasProps> = ({
  interaction,
  onUpdateInteraction,
  onGenerateSummary,
  isGeneratingAI,
  saveStatus,
  saveError,
  onRetrySave,
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState(interaction.title || 'Naveen Chintan');
  const [selectedSticker, setSelectedSticker] = useState<GardenSticker | null>(null);
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  const [activeSpeakingMsgId, setActiveSpeakingMsgId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setTitleInput(interaction.title || 'Naveen Chintan');
  }, [interaction.id, interaction.title]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [interaction.messages, isGeneratingAI]);

  const handleTitleSubmit = () => {
    setIsEditingTitle(false);
    if (titleInput.trim() && titleInput !== interaction.title) {
      onUpdateInteraction(
        {
          ...interaction,
          title: titleInput.trim(),
          updatedAt: new Date().toISOString(),
        },
        true
      );
    }
  };

  const handleModeChange = (mode: ReflectionMode) => {
    onUpdateInteraction(
      {
        ...interaction,
        reflectionType: mode,
        updatedAt: new Date().toISOString(),
      },
      true
    );
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 2000);
  };

  const handleSpeak = (id: string, text: string) => {
    if (activeSpeakingMsgId === id) {
      govindAudio.stopSpeaking();
      setActiveSpeakingMsgId(null);
    } else {
      setActiveSpeakingMsgId(id);
      govindAudio.speak(
        text,
        id,
        () => setActiveSpeakingMsgId(id),
        () => setActiveSpeakingMsgId(null)
      );
    }
  };

  const handleSendMessage = async (customPrompt?: string, stickerOverride?: GardenSticker) => {
    const textToSend = customPrompt || inputText;
    const stickerToAttach = stickerOverride || selectedSticker || undefined;
    if (!textToSend.trim() || isGeneratingAI) return;

    const userMsg: ChatMessage = {
      id: 'msg-' + Date.now() + '-u',
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toISOString(),
      sticker: stickerToAttach,
    };

    let newTitle = interaction.title;
    if (
      (!newTitle ||
        newTitle === 'New Reflection' ||
        newTitle === 'Untitled Reflection' ||
        newTitle === 'Naveen Chintan' ||
        newTitle === 'Naveen Chintan (New Reflection)') &&
      textToSend.length > 0
    ) {
      newTitle = textToSend.slice(0, 38).replace(/[\r\n]+/g, ' ') + (textToSend.length > 38 ? '...' : '');
      setTitleInput(newTitle);
    }

    const updatedMessages = [...interaction.messages, userMsg];
    const updatedInteraction: JournalInteraction = {
      ...interaction,
      title: newTitle,
      messages: updatedMessages,
      updatedAt: new Date().toISOString(),
    };

    setInputText('');
    setSelectedSticker(null);
    setShowStickerPicker(false);
    await onUpdateInteraction(updatedInteraction, true);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const userMessages = interaction.messages.filter((m) => m.role === 'user');
  const aiMessages = interaction.messages.filter((m) => m.role === 'model');
  const latestAiMessage = aiMessages[aiMessages.length - 1];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#FAF8F2] text-[#203D32] relative overflow-hidden">
      {/* Extremely subtle, almost invisible background peacock-feather line motif */}
      <div 
        className="pointer-events-none absolute inset-0 z-0 flex items-center justify-center opacity-[0.035] overflow-hidden"
        aria-hidden="true"
      >
        <svg
          viewBox="0 0 800 800"
          className="w-[900px] h-[900px] text-[#203D32]"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.2"
        >
          {/* Subtle line motif of peacock eye and radiating spiritual plume */}
          <circle cx="400" cy="350" r="120" />
          <circle cx="400" cy="350" r="75" />
          <ellipse cx="400" cy="350" rx="35" ry="50" />
          <path d="M400 200 C360 260 360 440 400 500 C440 440 440 260 400 200 Z" />
          <path d="M400 500 C380 620 370 700 360 800" />
          <path d="M400 350 C320 310 240 250 180 180" />
          <path d="M400 350 C480 310 560 250 620 180" />
          <path d="M400 380 C310 370 220 340 140 300" />
          <path d="M400 380 C490 370 580 340 660 300" />
          <path d="M400 420 C320 440 250 450 180 470" />
          <path d="M400 420 C480 440 550 450 620 470" />
        </svg>
      </div>

      {/* Top Header & Segmented Navigation */}
      <div className="relative z-10 border-b border-[#E5E0D4] bg-[#FAF8F2]/90 backdrop-blur-xs px-5 sm:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
        {/* Title, Date & Sacred Counseling Journey Breadcrumb */}
        <div className="flex flex-col gap-0.5 min-w-[220px]">
          <div className="flex items-center gap-2">
            {isEditingTitle ? (
              <div className="flex items-center gap-2">
                <input
                  id="reflection-title-input"
                  type="text"
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  onBlur={handleTitleSubmit}
                  onKeyDown={(e) => e.key === 'Enter' && handleTitleSubmit()}
                  autoFocus
                  className="font-serif text-base sm:text-lg font-semibold text-[#203D32] bg-white border border-[#E5E0D4] rounded-lg px-2.5 py-0.5 focus:outline-none focus:border-[#203D32]"
                />
                <button
                  onClick={handleTitleSubmit}
                  className="text-xs font-serif bg-[#203D32] text-white px-2.5 py-1 rounded-lg hover:bg-[#172D25] cursor-pointer"
                >
                  Surakshit
                </button>
              </div>
            ) : (
              <h2
                id="reflection-title-heading"
                onClick={() => setIsEditingTitle(true)}
                className="font-serif text-base sm:text-lg font-semibold text-[#203D32] cursor-pointer hover:text-[#167C78] transition-colors flex items-center gap-2 group select-none"
                title="Sheershak badalne ke liye click karein"
              >
                <span>{interaction.title || 'Naveen Chintan'}</span>
                <span className="text-[10px] text-[#7C8B82] font-sans opacity-0 group-hover:opacity-100 transition-opacity">
                  (Sampadit)
                </span>
              </h2>
            )}
          </div>

          {/* Date & Journey Stage */}
          <div className="flex items-center gap-3 text-[11px] text-[#7C8B82] font-serif">
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3 text-[#A2ADA7]" />
              <span>
                {new Date(interaction.createdAt).toLocaleDateString('en-IN', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </span>
            </span>
            <span>•</span>
            <span className="text-[#627267]">
              Thehrav → Abhivyakti → Chintan → Bodh
            </span>
          </div>
        </div>

        {/* Clean Segmented Navigation with Thin Active Underline */}
        <div className="flex items-center gap-6 text-xs sm:text-sm font-serif">
          <button
            id="mode-reflection-tab"
            onClick={() => handleModeChange('reflection')}
            className={`pb-1.5 transition-colors cursor-pointer relative ${
              interaction.reflectionType === 'reflection'
                ? 'text-[#203D32] font-semibold border-b-2 border-[#203D32]'
                : 'text-[#7C8B82] hover:text-[#203D32]'
            }`}
          >
            Margdarshan
          </button>
          <button
            id="mode-brainstorm-tab"
            onClick={() => handleModeChange('brainstorm')}
            className={`pb-1.5 transition-colors cursor-pointer relative ${
              interaction.reflectionType === 'brainstorm'
                ? 'text-[#203D32] font-semibold border-b-2 border-[#203D32]'
                : 'text-[#7C8B82] hover:text-[#203D32]'
            }`}
          >
            Drishtikon
          </button>
          <button
            id="mode-summary-tab"
            onClick={() => handleModeChange('summary')}
            className={`pb-1.5 transition-colors cursor-pointer relative ${
              interaction.reflectionType === 'summary'
                ? 'text-[#203D32] font-semibold border-b-2 border-[#203D32]'
                : 'text-[#7C8B82] hover:text-[#203D32]'
            }`}
          >
            Saar
          </button>
        </div>

        {/* Quiet Firestore Status Indicator */}
        <div id="save-status-badge" className="flex items-center text-[11px] font-serif">
          {saveStatus === 'saving' && (
            <span className="inline-flex items-center gap-1.5 text-[#7A5824]">
              <RefreshCw className="h-3 w-3 animate-spin text-[#B89548]" />
              <span>Surakshit ho raha hai...</span>
            </span>
          )}
          {saveStatus === 'saved' && (
            <span className="inline-flex items-center gap-1 text-[#2D5A43]">
              <BookmarkCheck className="h-3.5 w-3.5 text-[#2D5A43]" />
              <span>Surakshit</span>
            </span>
          )}
          {saveStatus === 'error' && (
            <div className="inline-flex items-center gap-1 text-red-700">
              <AlertCircle className="h-3 w-3" />
              <span>Truti hui</span>
              <button
                id="retry-save-pill-btn"
                onClick={onRetrySave}
                className="underline ml-1 cursor-pointer font-medium"
              >
                Retry
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Save Error Alert Banner if any */}
      {saveError && (
        <div className="relative z-10 bg-[#FFF5F5] border-b border-red-200 px-5 py-2 text-xs text-red-800 flex items-center justify-between font-serif">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-red-600 shrink-0" />
            <span>{saveError}</span>
          </div>
          <button
            id="retry-save-banner-btn"
            onClick={onRetrySave}
            className="rounded px-2.5 py-1 text-xs font-serif bg-red-700 text-white hover:bg-red-800 cursor-pointer"
          >
            Punah Surakshit Karein
          </button>
        </div>
      )}

      {/* Main Sanctuary Area: Scrollable Reading Experience */}
      <div className="relative z-10 flex-1 overflow-y-auto px-4 sm:px-8 py-6 space-y-6">
        {interaction.messages.length === 0 ? (
          /* Empty Sanctuary Welcome: Calm, Sacred, Non-distracting */
          <div className="max-w-2xl mx-auto py-8 text-center">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-white border border-[#E5E0D4] shadow-xs mb-4">
              <GoldenPeacockLogo size="md" />
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl font-normal text-[#203D32] tracking-wide mb-2">
              Shri Govind Sharanam
            </h1>
            <p className="text-xs sm:text-sm text-[#627267] font-serif leading-relaxed max-w-lg mx-auto mb-8">
              &ldquo;Thehriye, aur apne hriday par haath rakhkar antarman ki aawaz suniye. Bina kisi sankoch ke apna har bhaar yahan vyakt kijiye.&rdquo;
            </p>

            {/* Subtle Contemplation Inquiries */}
            <div className="text-left bg-white/70 border border-[#E5E0D4] rounded-2xl p-5 mb-4">
              <span className="text-xs font-serif font-semibold text-[#203D32] block mb-3">
                Manovritti evam Prashna (Contemplative Inquiries):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {CONTEMPLATION_QUESTIONS.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(q.text)}
                    className="p-3 rounded-xl border border-[#E5E0D4] bg-[#FAF8F2] hover:bg-white hover:border-[#B89548]/40 text-left transition-all group cursor-pointer"
                  >
                    <span className="font-serif text-xs font-semibold text-[#203D32] block mb-1 group-hover:text-[#167C78]">
                      {q.label}
                    </span>
                    <p className="text-[11px] text-[#627267] font-serif line-clamp-2 italic leading-relaxed">
                      &ldquo;{q.text}&rdquo;
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Continuous Sacred Reading Flow: Dignified, Not Chat Bubbles */
          <div className="max-w-3xl mx-auto space-y-6">
            {/* User's Original Reflection Section */}
            {userMessages.length > 0 && (
              <div className="bg-white/90 border border-[#E5E0D4] rounded-2xl p-5 sm:p-6 shadow-2xs">
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#E5E0D4] text-xs font-serif text-[#7C8B82]">
                  <span className="font-medium text-[#203D32]">Aapka Chintan (Your Reflection)</span>
                  <span>{new Date(userMessages[0].timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <div className="font-serif text-sm sm:text-base text-[#203D32] leading-relaxed whitespace-pre-wrap">
                  {userMessages[userMessages.length - 1].content}
                </div>
                {userMessages[userMessages.length - 1].sticker && (
                  <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-serif bg-[#F5F3ED] border border-[#E5E0D4] text-[#627267]">
                    <span>{userMessages[userMessages.length - 1].sticker?.emoji}</span>
                    <span>{userMessages[userMessages.length - 1].sticker?.name}</span>
                  </div>
                )}
              </div>
            )}

            {/* AI Response: Calm Margdarshan Reading Flow */}
            {aiMessages.map((aiMsg) => {
              const isSpeakingThis = activeSpeakingMsgId === aiMsg.id;

              return (
                <div 
                  key={aiMsg.id} 
                  id={`guidance-card-${aiMsg.id}`}
                  className="bg-white border border-[#E5E0D4] rounded-2xl p-6 sm:p-8 shadow-xs space-y-5"
                >
                  {/* Margdarshan Header with hairline divider */}
                  <div className="flex items-center justify-between pb-3 border-b border-[#E5E0D4]">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-[#17241E] p-0.5 shrink-0 overflow-hidden border border-[#B89548]/30">
                        <GoldenPeacockLogo size="sm" />
                      </div>
                      <span className="font-serif text-base font-semibold text-[#203D32] tracking-wide">
                        Margdarshan
                      </span>
                    </div>

                    {/* Quiet Controls: Komal Vaani & Copy */}
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => handleSpeak(aiMsg.id, aiMsg.content)}
                        className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-serif transition-colors cursor-pointer border ${
                          isSpeakingThis
                            ? 'bg-[#F2ECE1] text-[#7A5824] border-[#B89548]/50'
                            : 'bg-[#FAF8F2] text-[#627267] border-[#E5E0D4] hover:text-[#203D32]'
                        }`}
                        title={isSpeakingThis ? "Vaani rokein" : "Komal Vaani sunein"}
                      >
                        {isSpeakingThis ? (
                          <>
                            <VolumeX className="h-3.5 w-3.5 text-[#B89548]" />
                            <span>Rokein</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="h-3.5 w-3.5 text-[#627267]" />
                            <span>Komal Vaani</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => handleCopy(aiMsg.id, aiMsg.content)}
                        className="text-[#7C8B82] hover:text-[#203D32] p-1 cursor-pointer"
                        title="Copy karein"
                      >
                        {copiedMessageId === aiMsg.id ? (
                          <Check className="h-3.5 w-3.5 text-[#203D32]" />
                        ) : (
                          <Copy className="h-3.5 w-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Sanskrit Shloka Quote if attached */}
                  {aiMsg.shloka && (
                    <div className="my-3 pl-4 py-2 border-l-2 border-[#B89548]/60 bg-[#FAF8F2] rounded-r-xl text-xs font-serif">
                      <span className="text-[11px] text-[#B89548] font-semibold uppercase tracking-wider block mb-1">
                        {aiMsg.shloka.name || 'Shashwat Shloka'}
                      </span>
                      <p className="text-sm font-semibold text-[#203D32] italic mb-1 leading-relaxed">
                        &ldquo;{aiMsg.shloka.sanskrit}&rdquo;
                      </p>
                      {aiMsg.shloka.translation && (
                        <p className="text-xs text-[#627267] font-sans leading-relaxed">
                          {aiMsg.shloka.translation}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Margdarshan Guidance Body: Calm Editorial Typography */}
                  <div className="prose prose-sm max-w-none text-[#203D32] font-serif text-sm sm:text-base leading-relaxed space-y-4">
                    <ReactMarkdown>{aiMsg.content}</ReactMarkdown>
                  </div>
                </div>
              );
            })}

            {/* AI Thought Generation Progress */}
            {isGeneratingAI && (
              <div className="bg-white/80 border border-[#E5E0D4] rounded-2xl p-5 flex items-center gap-3">
                <div className="w-5 h-5 rounded-full border-2 border-[#E5E0D4] border-t-[#203D32] animate-spin shrink-0"></div>
                <p className="text-xs font-serif text-[#627267]">
                  Govind aapke antarman ke chintan ko dhyanpoorvak sun rahe hain...
                </p>
              </div>
            )}

            {/* Summary / Saar Section if present */}
            {interaction.summary && (
              <div className="bg-[#FAF8F2] border border-[#B89548]/30 rounded-2xl p-6 shadow-2xs space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[#E5E0D4]">
                  <span className="font-serif text-sm font-semibold text-[#203D32]">
                    Saaransh evam Nishkama Karma Sandesh
                  </span>
                  <button
                    onClick={() => handleCopy('summary', interaction.summary!)}
                    className="text-xs text-[#7C8B82] hover:text-[#203D32] flex items-center gap-1 cursor-pointer font-serif"
                  >
                    {copiedMessageId === 'summary' ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    <span>{copiedMessageId === 'summary' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="prose prose-sm max-w-none text-[#203D32] font-serif text-xs sm:text-sm leading-relaxed">
                  <ReactMarkdown>{interaction.summary}</ReactMarkdown>
                </div>
              </div>
            )}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Visual Centerpiece: Large Journal Writing Area & Quiet Action Buttons */}
      <div className="relative z-10 border-t border-[#E5E0D4] bg-[#FAF8F2] p-4 sm:p-6 shadow-[0_-4px_24px_rgba(32,61,50,0.03)]">
        <div className="max-w-3xl mx-auto space-y-3">
          {/* Secondary Actions Row: Clean, quiet, and outlined */}
          <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 text-xs font-serif">
            <div className="flex items-center gap-2">
              <button
                id="quick-brainstorm-btn"
                onClick={() =>
                  handleSendMessage(
                    'Hey Govind! Is sthiti ko samajhne ke liye mujhe vyavaharik evam adhyatmik Drishtikon (Angles) pradaan karein.'
                  )
                }
                disabled={isGeneratingAI}
                className="px-3 py-1 rounded-full border border-[#E5E0D4] bg-white text-[#627267] hover:text-[#203D32] hover:border-[#203D32]/40 transition-colors cursor-pointer whitespace-nowrap"
              >
                Drishtikon (Explore Angles)
              </button>
              <button
                id="quick-summary-btn"
                onClick={onGenerateSummary}
                disabled={isGeneratingAI || interaction.messages.length === 0}
                className="px-3 py-1 rounded-full border border-[#E5E0D4] bg-white text-[#627267] hover:text-[#203D32] hover:border-[#203D32]/40 transition-colors disabled:opacity-40 cursor-pointer whitespace-nowrap"
              >
                Saar (View Summary)
              </button>
            </div>

            {/* Subtle Offering Trigger */}
            <div className="flex items-center gap-2">
              {selectedSticker && (
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#EDEAE1] text-xs font-serif text-[#203D32]">
                  <span>{selectedSticker.emoji}</span>
                  <span className="hidden sm:inline">{selectedSticker.name}</span>
                  <button onClick={() => setSelectedSticker(null)} className="cursor-pointer hover:text-red-700">
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
              <button
                onClick={() => setShowStickerPicker(!showStickerPicker)}
                className="text-xs font-serif text-[#7C8B82] hover:text-[#203D32] cursor-pointer"
              >
                {showStickerPicker ? 'Bhav Samarpan ▲' : 'Bhav Samarpan ▼'}
              </button>
            </div>
          </div>

          {/* Quick Offering Selector */}
          {showStickerPicker && (
            <div className="p-2.5 bg-white border border-[#E5E0D4] rounded-xl flex flex-wrap gap-2 text-xs font-serif">
              {VRINDAVAN_GARDEN_STICKERS.map((st) => (
                <button
                  key={st.id}
                  onClick={() => {
                    setSelectedSticker(st);
                    setShowStickerPicker(false);
                  }}
                  className="px-2.5 py-1 rounded-lg border border-[#E5E0D4] hover:bg-[#FAF8F2] flex items-center gap-1.5 cursor-pointer text-[#203D32]"
                >
                  <span>{st.emoji}</span>
                  <span>{st.name}</span>
                </button>
              ))}
            </div>
          )}

          {/* Centerpiece Journal Input Box */}
          <div className="relative rounded-[20px] border border-[#E5E0D4] bg-white focus-within:border-[#203D32] focus-within:ring-2 focus-within:ring-[#203D32]/10 transition-all">
            <textarea
              id="reflection-input"
              ref={textareaRef}
              rows={4}
              placeholder="Apne man ki vyatha, virah, dukh, krodh, ya duvidha yahan vistaar se likhein... Govind sun rahe hain."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isGeneratingAI}
              className="w-full resize-none p-5 sm:p-6 pr-40 text-sm sm:text-base text-[#203D32] placeholder-[#A2ADA7] focus:outline-none rounded-[20px] font-serif leading-relaxed bg-transparent"
              style={{ minHeight: '120px' }}
            />

            {/* Bottom-right inside input: Margdarshan Lein primary button */}
            <div className="absolute right-4 bottom-4 flex items-center gap-3">
              <button
                id="btn-submit"
                onClick={() => handleSendMessage()}
                disabled={!inputText.trim() || isGeneratingAI}
                className="flex items-center gap-2 rounded-xl bg-[#203D32] hover:bg-[#172D25] px-5 py-2.5 text-xs sm:text-sm font-serif font-semibold text-white disabled:opacity-40 transition-all cursor-pointer shadow-xs"
                title="Govind se margdarshan prapt karein"
              >
                <span>Margdarshan Lein</span>
                <Compass className="h-3.5 w-3.5 text-[#B89548]" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-[#7C8B82] font-serif px-1">
            <span>Pavitra Ekaant • Antaratma se Samvaad</span>
            <span className="hidden sm:inline">Preshit karne hetu <kbd className="bg-[#EDEAE1] px-1 py-0.5 rounded text-[#203D32] font-sans">Cmd/Ctrl + Enter</kbd> dabayein</span>
          </div>
        </div>
      </div>
    </div>
  );
};
