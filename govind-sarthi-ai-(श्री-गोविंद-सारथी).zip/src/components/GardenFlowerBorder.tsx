import React, { useState } from 'react';

// Realistic 3D Golden Lotus asset
import goldenLotusImg from '../assets/images/golden_lotus_flower_3d_1788645521008.jpg';

interface GardenFlowerBorderProps {
  position?: 'top' | 'bottom' | 'both';
  className?: string;
  show3DCornerLotuses?: boolean;
}

export const GardenFlowerBorder: React.FC<GardenFlowerBorderProps> = ({
  position = 'both',
  className = '',
  show3DCornerLotuses = true,
}) => {
  const [activeFlowerIdx, setActiveFlowerIdx] = useState<number | null>(null);

  // Array of cute stylized and 3D botanical flower blossoms for the garland
  const garlandFlowers = [
    { type: 'lotus', label: 'Kamal (Sacred Lotus)', color: '#f472b6', glow: 'rgba(244,114,182,0.4)', size: 28 },
    { type: 'champa', label: 'Champa (Golden Magnolia)', color: '#fbbf24', glow: 'rgba(251,191,36,0.4)', size: 22 },
    { type: 'parijat', label: 'Parijat (Night Jasmine)', color: '#fda4af', glow: 'rgba(253,164,175,0.4)', size: 24 },
    { type: 'bud', label: 'Kamal Kalika (Lotus Bud)', color: '#fbcfe8', glow: 'rgba(251,207,232,0.3)', size: 18 },
    { type: 'golden', label: 'Divya Suvarna Kamal', color: '#f59e0b', glow: 'rgba(245,158,11,0.5)', size: 26 },
    { type: 'parijat', label: 'Parijat Blossom', color: '#fda4af', glow: 'rgba(253,164,175,0.4)', size: 24 },
    { type: 'champa', label: 'Swarna Pushpa', color: '#fbbf24', glow: 'rgba(251,191,36,0.4)', size: 22 },
    { type: 'lotus', label: 'Vrindavan Padam', color: '#f472b6', glow: 'rgba(244,114,182,0.4)', size: 28 },
  ];

  const renderGarlandBar = (isTop: boolean) => (
    <div
      className={`relative w-full overflow-hidden flex items-center justify-between px-2 sm:px-6 py-1 select-none pointer-events-auto ${
        isTop ? '-top-3' : '-bottom-3'
      }`}
    >
      {/* Delicate winding vine line */}
      <div className="absolute inset-x-4 top-1/2 h-[1.5px] bg-gradient-to-r from-transparent via-[#2d5a43]/30 to-transparent -translate-y-1/2" />

      {/* Row of charming 3D flowers with interactive gentle hover sways */}
      <div className="w-full flex items-center justify-around z-10">
        {garlandFlowers.map((flower, idx) => {
          const isHovered = activeFlowerIdx === (isTop ? idx : idx + 10);
          return (
            <div
              key={`${isTop ? 'top' : 'bot'}-${idx}`}
              onMouseEnter={() => setActiveFlowerIdx(isTop ? idx : idx + 10)}
              onMouseLeave={() => setActiveFlowerIdx(null)}
              className="relative group cursor-pointer transition-transform duration-300 transform hover:scale-125 hover:-translate-y-1"
              title={flower.label}
            >
              {/* Petal glow aura */}
              <div
                className={`absolute inset-0 rounded-full blur-xs transition-opacity duration-300 ${
                  isHovered ? 'opacity-100' : 'opacity-40'
                }`}
                style={{ backgroundColor: flower.glow }}
              />

              {/* Realistic SVG blossom icon */}
              <svg
                width={flower.size}
                height={flower.size}
                viewBox="0 0 40 40"
                className="drop-shadow-[0_2px_4px_rgba(0,0,0,0.12)] transition-transform duration-500"
                style={{
                  transform: isHovered ? 'rotate(18deg) scale(1.15)' : 'rotate(0deg)',
                }}
              >
                <defs>
                  <radialGradient id={`lotusGrad-${idx}-${isTop ? 't' : 'b'}`} cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#fffbeb" />
                    <stop offset="40%" stopColor="#fbcfe8" />
                    <stop offset="85%" stopColor="#f472b6" />
                    <stop offset="100%" stopColor="#db2777" />
                  </radialGradient>
                  <radialGradient id={`goldGrad-${idx}-${isTop ? 't' : 'b'}`} cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#fffbeb" />
                    <stop offset="50%" stopColor="#fde047" />
                    <stop offset="100%" stopColor="#d97706" />
                  </radialGradient>
                  <linearGradient id={`leafGrad-${idx}-${isTop ? 't' : 'b'}`} x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#86efac" />
                    <stop offset="100%" stopColor="#15803d" />
                  </linearGradient>
                </defs>

                {/* Underleaf sepals */}
                <path
                  d="M12 28 C16 32 24 32 28 28 C25 31 15 31 12 28 Z"
                  fill={`url(#leafGrad-${idx}-${isTop ? 't' : 'b'})`}
                />

                {flower.type === 'lotus' && (
                  <>
                    {/* Layer 1 - Outer petals */}
                    <path
                      d="M20 4 C14 14 10 24 20 32 C30 24 26 14 20 4 Z"
                      fill={`url(#lotusGrad-${idx}-${isTop ? 't' : 'b'})`}
                      opacity="0.9"
                    />
                    <path
                      d="M10 16 C8 24 16 30 20 32 C15 28 11 20 10 16 Z"
                      fill={`url(#lotusGrad-${idx}-${isTop ? 't' : 'b'})`}
                    />
                    <path
                      d="M30 16 C32 24 24 30 20 32 C25 28 29 20 30 16 Z"
                      fill={`url(#lotusGrad-${idx}-${isTop ? 't' : 'b'})`}
                    />
                    {/* Golden Pollen Anther Center */}
                    <circle cx="20" cy="22" r="3.2" fill="#fef08a" />
                    <circle cx="20" cy="22" r="1.6" fill="#ca8a04" />
                  </>
                )}

                {flower.type === 'golden' && (
                  <>
                    <path
                      d="M20 5 C12 15 10 25 20 33 C30 25 28 15 20 5 Z"
                      fill={`url(#goldGrad-${idx}-${isTop ? 't' : 'b'})`}
                    />
                    <ellipse cx="20" cy="21" rx="5" ry="4" fill="#fef3c7" opacity="0.8" />
                    <circle cx="20" cy="21" r="2.2" fill="#b45309" />
                  </>
                )}

                {(flower.type === 'champa' || flower.type === 'parijat') && (
                  <>
                    {/* 5-petaled cute pinwheel flower */}
                    {[0, 72, 144, 216, 288].map((angle, petalI) => (
                      <ellipse
                        key={petalI}
                        cx="20"
                        cy="13"
                        rx="3.8"
                        ry="7.5"
                        transform={`rotate(${angle} 20 20)`}
                        fill={flower.type === 'champa' ? '#fef08a' : '#fff1f2'}
                        stroke="#f59e0b"
                        strokeWidth="0.5"
                      />
                    ))}
                    <circle cx="20" cy="20" r="2.8" fill="#f97316" />
                  </>
                )}

                {flower.type === 'bud' && (
                  <>
                    <path
                      d="M20 8 C16 16 15 24 20 30 C25 24 24 16 20 8 Z"
                      fill={`url(#lotusGrad-${idx}-${isTop ? 't' : 'b'})`}
                    />
                    <path d="M18 16 C17 22 20 28 20 30" stroke="#15803d" strokeWidth="1" fill="none" />
                  </>
                )}
              </svg>

              {/* Dew drop sparkle */}
              <span className="absolute top-0 right-0 w-1 h-1 bg-white rounded-full shadow-xs animate-ping" />
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className={`relative ${className}`}>
      {/* 3D Corner Lotus Ornaments */}
      {show3DCornerLotuses && (
        <>
          {/* Top-Left Corner 3D Lotus Flower */}
          <div className="absolute -top-5 -left-5 z-20 pointer-events-none group">
            <div className="relative w-11 h-11 sm:w-13 sm:h-13 rounded-full overflow-hidden p-0.5 bg-gradient-to-br from-amber-200 via-pink-200 to-emerald-300 shadow-[0_4px_12px_rgba(244,114,182,0.35)] border border-white/80 transform -rotate-12 transition-transform duration-500 hover:rotate-0 hover:scale-110">
              <img
                src={goldenLotusImg}
                alt="Sacred 3D Lotus Blossom"
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 rounded-full ring-1 ring-amber-300/60 pointer-events-none" />
            </div>
          </div>

          {/* Top-Right Corner 3D Lotus Flower */}
          <div className="absolute -top-5 -right-5 z-20 pointer-events-none group">
            <div className="relative w-11 h-11 sm:w-13 sm:h-13 rounded-full overflow-hidden p-0.5 bg-gradient-to-bl from-amber-200 via-pink-200 to-emerald-300 shadow-[0_4px_12px_rgba(244,114,182,0.35)] border border-white/80 transform rotate-12 transition-transform duration-500 hover:rotate-0 hover:scale-110">
              <img
                src={goldenLotusImg}
                alt="Sacred 3D Lotus Blossom"
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 rounded-full ring-1 ring-amber-300/60 pointer-events-none" />
            </div>
          </div>

          {/* Bottom-Left Corner 3D Lotus Flower */}
          <div className="absolute -bottom-5 -left-5 z-20 pointer-events-none group">
            <div className="relative w-10 h-10 sm:w-12 sm:h-12 rounded-full overflow-hidden p-0.5 bg-gradient-to-tr from-amber-200 via-pink-200 to-emerald-300 shadow-[0_4px_12px_rgba(244,114,182,0.35)] border border-white/80 transform rotate-45 transition-transform duration-500 hover:scale-110">
              <img
                src={goldenLotusImg}
                alt="Sacred 3D Lotus Blossom"
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Bottom-Right Corner 3D Lotus Flower */}
          <div className="absolute -bottom-5 -right-5 z-20 pointer-events-none group">
            <div className="relative w-10 h-10 sm:w-12 sm:h-12 rounded-full overflow-hidden p-0.5 bg-gradient-to-tl from-amber-200 via-pink-200 to-emerald-300 shadow-[0_4px_12px_rgba(244,114,182,0.35)] border border-white/80 transform -rotate-45 transition-transform duration-500 hover:scale-110">
              <img
                src={goldenLotusImg}
                alt="Sacred 3D Lotus Blossom"
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </>
      )}

      {(position === 'top' || position === 'both') && renderGarlandBar(true)}
      {(position === 'bottom' || position === 'both') && renderGarlandBar(false)}
    </div>
  );
};
