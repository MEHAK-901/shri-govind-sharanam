import React, { useEffect, useRef } from 'react';

interface Petal {
  x: number;
  y: number;
  z: number;
  size: number;
  color: string;
  opacity: number;
  speedX: number;
  speedY: number;
  angle: number;
  spinSpeed: number;
  tilt: number;
  tiltSpeed: number;
}

export const PetalsCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    const numPetals = 38;
    const mouse = { x: null as number | null, y: null as number | null };

    const petalTypes = [
      { color: '#f8b4c4', size: 12, opacity: 0.65 },
      { color: '#fce4ec', size: 10, opacity: 0.7 },
      { color: '#fbd38d', size: 11, opacity: 0.6 },
      { color: '#d6bcfa', size: 9, opacity: 0.55 },
    ];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();

    const petals: Petal[] = [];
    for (let i = 0; i < numPetals; i++) {
      const type = petalTypes[Math.floor(Math.random() * petalTypes.length)];
      petals.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        z: Math.random() * 0.8 + 0.4,
        size: type.size,
        color: type.color,
        opacity: type.opacity,
        speedX: (Math.random() - 0.5) * 0.8,
        speedY: Math.random() * 0.8 + 0.4,
        angle: Math.random() * 360,
        spinSpeed: (Math.random() - 0.5) * 1.5,
        tilt: Math.random() * 10,
        tiltSpeed: Math.random() * 0.05 + 0.02,
      });
    }

    const onResize = () => resize();
    const onMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };
    const onMouseLeave = () => {
      mouse.x = null;
      mouse.y = null;
    };

    window.addEventListener('resize', onResize);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseleave', onMouseLeave);

    const drawPetal = (p: Petal) => {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((p.angle * Math.PI) / 180);
      ctx.scale(p.z, Math.sin(p.tilt) * p.z);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.opacity * p.z;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.bezierCurveTo(p.size / 2, -p.size / 2, p.size, p.size / 3, 0, p.size * 1.5);
      ctx.bezierCurveTo(-p.size, p.size / 3, -p.size / 2, -p.size / 2, 0, 0);
      ctx.fill();
      ctx.restore();
    };

    const updatePetal = (p: Petal) => {
      p.y += p.speedY * p.z;
      p.x += p.speedX * p.z;
      p.angle += p.spinSpeed;
      p.tilt += p.tiltSpeed;

      if (mouse.x !== null && mouse.y !== null) {
        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120 && dist > 0) {
          p.x -= (dx / dist) * 1.8;
          p.y -= (dy / dist) * 1.8;
        }
      }

      if (p.y > canvas.height + 40) {
        p.y = -20;
        p.x = Math.random() * canvas.width;
      }
      if (p.x > canvas.width + 40) p.x = -20;
      if (p.x < -40) p.x = canvas.width + 20;
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < petals.length; i++) {
        updatePetal(petals[i]);
        drawPetal(petals[i]);
      }
      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseleave', onMouseLeave);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="petals-canvas"
      className="fixed inset-0 pointer-events-none z-10"
      aria-hidden="true"
    />
  );
};
