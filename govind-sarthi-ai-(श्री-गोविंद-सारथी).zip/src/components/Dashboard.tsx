import React, { useState, useEffect, useCallback } from 'react';
import { 
  LogOut, 
  Menu, 
  ShieldCheck, 
  Music,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { HistorySidebar } from './HistorySidebar';
import { ReflectionCanvas } from './ReflectionCanvas';
import { 
  fetchUserInteractions, 
  saveUserInteraction, 
  deleteUserInteraction, 
} from '../firebase';
import { GoldenPeacockLogo } from './GoldenPeacockLogo';
import { govindAudio } from '../utils/audioManager';
import type { UserProfile, JournalInteraction, ChatMessage, ReflectionMode } from '../types';

interface DashboardProps {
  user: UserProfile;
  onSignOut: () => void;
  onOpenThreatModel: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  user,
  onSignOut,
  onOpenThreatModel,
}) => {
  const [interactions, setInteractions] = useState<JournalInteraction[]>([]);
  const [activeInteractionId, setActiveInteractionId] = useState<string | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [saveError, setSaveError] = useState<string | null>(null);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Audio states
  const [isMusicPlaying, setIsMusicPlaying] = useState(govindAudio.getIsPlaying());
  const [isVoiceMuted, setIsVoiceMuted] = useState(govindAudio.getIsMuted());
  const [isAutoSpeak, setIsAutoSpeak] = useState(govindAudio.getAutoSpeakEnabled());

  const toggleMusic = () => {
    const playing = govindAudio.toggleAmbientMusic();
    setIsMusicPlaying(playing);
  };

  const toggleVoice = () => {
    const muted = govindAudio.toggleMute();
    setIsVoiceMuted(muted);
  };

  const toggleAutoSpeak = () => {
    const nextVal = !isAutoSpeak;
    govindAudio.setAutoSpeakEnabled(nextVal);
    setIsAutoSpeak(nextVal);
  };

  // Helper to generate empty reflection session
  const createEmptySession = useCallback((mode: ReflectionMode = 'reflection'): JournalInteraction => {
    const id = 'session-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7);
    return {
      id,
      userId: user.uid,
      title: 'Naveen Chintan (New Reflection)',
      reflectionType: mode,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };
  }, [user.uid]);

  // Load user interactions from Firestore
  const loadInteractions = useCallback(async () => {
    setIsLoadingHistory(true);
    setSaveError(null);
    try {
      const items = await fetchUserInteractions(user.uid);
      setInteractions(items);
      if (items.length > 0) {
        setActiveInteractionId(items[0].id);
      } else {
        const initial = createEmptySession();
        setInteractions([initial]);
        setActiveInteractionId(initial.id);
      }
    } catch (err: any) {
      console.error('Failed to load reflections from Firestore:', err);
      setSaveError('Poorva chintan load nahi ho sake. Sthaniya chintan satr uplabdh hai.');
      const fallback = createEmptySession();
      setInteractions([fallback]);
      setActiveInteractionId(fallback.id);
    } finally {
      setIsLoadingHistory(false);
    }
  }, [user.uid, createEmptySession]);

  useEffect(() => {
    loadInteractions();
  }, [loadInteractions]);

  // Active interaction object
  const activeInteraction = interactions.find((i) => i.id === activeInteractionId) || interactions[0] || createEmptySession();

  // Save interaction to Firestore with error escalation & transaction verification
  const persistInteraction = async (interactionToSave: JournalInteraction) => {
    setSaveStatus('saving');
    setSaveError(null);
    try {
      await saveUserInteraction(interactionToSave);
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus((prev) => (prev === 'saved' ? 'idle' : prev)), 3000);
    } catch (err: any) {
      console.error('Firestore save failed:', err);
      setSaveStatus('error');
      setSaveError(err?.message || 'Chintan ko surakshit karne mein truti hui. Aap punah prayaas kar sakte hain.');
    }
  };

  // Update interaction in state and optionally in DB
  const handleUpdateInteraction = async (updated: JournalInteraction, shouldSaveToDb = true) => {
    setInteractions((prev) =>
      prev.map((item) => (item.id === updated.id ? updated : item))
    );

    if (shouldSaveToDb) {
      if (updated.messages.length > 0 || updated.title !== 'Naveen Chintan (New Reflection)') {
        await persistInteraction(updated);
      }
    }

    // Check if the last message was a user message needing Govind's counsel
    const lastMsg = updated.messages[updated.messages.length - 1];
    if (lastMsg && lastMsg.role === 'user' && !isGeneratingAI) {
      await requestGeminiReply(updated);
    }
  };

  // Call server-side Gemini API with resilient fallback ladder and Shloka injection
  const requestGeminiReply = async (session: JournalInteraction) => {
    setIsGeneratingAI(true);
    setSaveError(null);
    try {
      const response = await fetch('/api/gemini/reflect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: session.messages,
          mode: session.reflectionType,
          currentPrompt: '',
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      const data = await response.json();
      const replyText = data.reply || data.response || 'Govind tumhari baat sun rahe hain, Parth.';
      const modelUsed = data.modelUsed || 'gemini-3.6-flash';
      const shloka = data.shloka;

      const aiMsg: ChatMessage = {
        id: 'msg-' + Date.now() + '-m',
        role: 'model',
        content: replyText,
        timestamp: new Date().toISOString(),
        modelUsed,
        shloka,
      };

      const updatedSession: JournalInteraction = {
        ...session,
        messages: [...session.messages, aiMsg],
        updatedAt: new Date().toISOString(),
      };

      setInteractions((prev) =>
        prev.map((item) => (item.id === updatedSession.id ? updatedSession : item))
      );

      await persistInteraction(updatedSession);

      // Subtle vocal guidance only if user explicitly turned on auto-speak
      if (govindAudio.getAutoSpeakEnabled()) {
        govindAudio.speak(replyText, aiMsg.id);
      }
    } catch (err: any) {
      console.error('Gemini reflection request failed:', err);
      setSaveError(`Govind se sampark mein truti: ${err?.message || err}। Kripya punah prayaas karein.`);
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Generate executive summary & Nishkama Karma takeaways
  const handleGenerateSummary = async () => {
    if (activeInteraction.messages.length === 0 || isGeneratingAI) return;
    setIsGeneratingAI(true);
    setSaveError(null);

    try {
      const response = await fetch('/api/gemini/reflect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: activeInteraction.messages,
          mode: 'summary',
          currentPrompt: 'Parth ke is chintan ka saar, mool antardwandva aur nishkama karma ke kartavya-sootra pradaan karein.',
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server status ${response.status}`);
      }

      const data = await response.json();
      const summaryText = data.reply || '';

      const updatedSession: JournalInteraction = {
        ...activeInteraction,
        summary: summaryText,
        updatedAt: new Date().toISOString(),
      };

      setInteractions((prev) =>
        prev.map((item) => (item.id === updatedSession.id ? updatedSession : item))
      );

      await persistInteraction(updatedSession);
    } catch (err: any) {
      console.error('Failed to generate summary:', err);
      setSaveError(`Saaransh nirmaan mein truti: ${err?.message || err}`);
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Start a new reflection
  const handleNewReflection = () => {
    const newSession = createEmptySession();
    setInteractions((prev) => [newSession, ...prev]);
    setActiveInteractionId(newSession.id);
  };

  // Delete an interaction
  const handleDeleteInteraction = async (id: string) => {
    try {
      await deleteUserInteraction(user.uid, id);
      setInteractions((prev) => {
        const filtered = prev.filter((item) => item.id !== id);
        if (filtered.length === 0) {
          const fresh = createEmptySession();
          setActiveInteractionId(fresh.id);
          return [fresh];
        }
        if (activeInteractionId === id) {
          setActiveInteractionId(filtered[0].id);
        }
        return filtered;
      });
    } catch (err: any) {
      console.error('Delete failed:', err);
    }
  };

  // Retry save
  const handleRetrySave = () => {
    if (activeInteraction) {
      persistInteraction(activeInteraction);
    }
  };

  const displayName = user.displayName || 'Parth';

  return (
    <div className="h-screen w-screen flex flex-col bg-[#FAF8F2] text-[#203D32] overflow-hidden relative select-none">
      {/* Peaceful Sanctuary Header */}
      <header className="h-16 shrink-0 bg-[#FAF8F2] border-b border-[#E5E0D4] px-4 sm:px-6 flex items-center justify-between z-30">
        <div className="flex items-center gap-3">
          {/* Mobile reflections drawer toggle */}
          <button
            id="mobile-sidebar-toggle-btn"
            onClick={() => setIsMobileSidebarOpen(true)}
            className="md:hidden p-2 rounded-lg text-[#203D32] hover:bg-[#EDEAE1] transition-colors cursor-pointer"
            aria-label="Open reflections list"
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* Official Logo with clean sacred typography */}
          <GoldenPeacockLogo size="md" showText={true} />
        </div>

        {/* Quiet, Elegant Controls: Bansuri, Komal Vaani, Profile, Logout */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* Bansuri Sangeet: Quiet, elegant compact control */}
          <button
            id="btn-music-toggle"
            onClick={toggleMusic}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-serif transition-all cursor-pointer border ${
              isMusicPlaying
                ? 'bg-[#F2ECE1] text-[#7A5824] border-[#B89548]/50 shadow-2xs'
                : 'bg-transparent text-[#627267] border-[#E5E0D4] hover:bg-[#F5F3ED] hover:text-[#203D32]'
            }`}
            title="Bansuri Sangeet (Quiet flute meditation audio)"
          >
            <Music className={`h-3.5 w-3.5 ${isMusicPlaying ? 'text-[#B89548]' : 'text-[#7C8B82]'}`} />
            <span id="music-btn-text" className="hidden sm:inline">
              {isMusicPlaying ? 'Bansuri Sangeet' : 'Bansuri Sangeet'}
            </span>
          </button>

          {/* Komal Vaani: Quiet voice control */}
          <button
            id="btn-voice-toggle"
            onClick={toggleVoice}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-serif transition-all cursor-pointer border ${
              !isVoiceMuted
                ? 'bg-[#EBF2EE] text-[#1D4A38] border-[#203D32]/30'
                : 'bg-transparent text-[#7C8B82] border-[#E5E0D4] hover:bg-[#F5F3ED] hover:text-[#203D32]'
            }`}
            title="Komal Vaani (Spoken reflection guidance)"
          >
            {!isVoiceMuted ? (
              <>
                <Volume2 className="h-3.5 w-3.5 text-[#203D32]" />
                <span className="hidden sm:inline">Komal Vaani</span>
              </>
            ) : (
              <>
                <VolumeX className="h-3.5 w-3.5 text-[#7C8B82]" />
                <span className="hidden sm:inline">Vaani Maun</span>
              </>
            )}
          </button>

          {/* Threat Model info modal trigger - subtle */}
          <button
            id="threat-model-header-btn"
            onClick={onOpenThreatModel}
            className="hidden xl:inline-flex items-center gap-1.5 text-xs font-serif text-[#627267] hover:text-[#203D32] px-2.5 py-1 rounded-full border border-[#E5E0D4] hover:bg-[#F5F3ED] transition-colors cursor-pointer"
          >
            <ShieldCheck className="h-3.5 w-3.5 text-[#627267]" />
            <span>Suraksha</span>
          </button>

          {/* User Profile (Visually secondary) */}
          <div className="flex items-center gap-2 pl-2 border-l border-[#E5E0D4]">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt="User"
                referrerPolicy="no-referrer"
                className="h-7 w-7 rounded-full object-cover border border-[#E5E0D4]"
              />
            ) : (
              <div className="h-7 w-7 rounded-full bg-[#EDEAE1] text-[#203D32] flex items-center justify-center text-xs font-serif font-semibold border border-[#DCD7C9]">
                {displayName[0]}
              </div>
            )}
            <span id="user-display-name" className="text-xs font-medium text-[#203D32] hidden md:inline">
              {displayName}
            </span>
          </div>

          {/* Logout (Subtle text action) */}
          <button
            id="btn-logout"
            onClick={() => {
              govindAudio.stopAll();
              onSignOut();
            }}
            className="flex items-center gap-1 text-xs text-[#7C8B82] hover:text-[#203D32] p-1.5 rounded-lg hover:bg-[#F5F3ED] transition-colors cursor-pointer"
            title="Prasthan karein (Sign Out)"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden lg:inline text-xs font-serif">Prasthan</span>
          </button>
        </div>
      </header>

      {/* Main Sanctuary Workspace: History Sidebar + Main Reflection Canvas */}
      <div className="flex-1 flex overflow-hidden relative">
        <HistorySidebar
          interactions={interactions}
          activeInteractionId={activeInteractionId}
          onSelectInteraction={(id) => setActiveInteractionId(id)}
          onNewReflection={handleNewReflection}
          onDeleteInteraction={handleDeleteInteraction}
          isLoading={isLoadingHistory}
          isOpenMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
        />

        <ReflectionCanvas
          key={activeInteraction.id}
          interaction={activeInteraction}
          onUpdateInteraction={handleUpdateInteraction}
          onGenerateSummary={handleGenerateSummary}
          isGeneratingAI={isGeneratingAI}
          saveStatus={saveStatus}
          saveError={saveError}
          onRetrySave={handleRetrySave}
        />
      </div>
    </div>
  );
};
