import React from 'react';
import { ShieldCheck, Lock, Database, Cpu, Network, X, CheckCircle2 } from 'lucide-react';
import type { ThreatZoneCountermeasure } from '../types';

interface ThreatModelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const THREAT_MATRIX: ThreatZoneCountermeasure[] = [
  {
    zone: 'Input Surfaces',
    threatDescription: 'Untrusted user journal prompts, buffer exhaustion, prompt injection attempts via reflection inputs.',
    owaspReference: 'OWASP A03 / LLM02',
    countermeasureImplemented: 'Input truncation (8000 char cap), strict payload JSON schema validation on server, null-safe destructuring.',
    status: 'Enforced',
  },
  {
    zone: 'Planning & Reasoning',
    threatDescription: 'Indirect prompt injection or jailbreaks diverting Gemini from its reflective role into harmful commands.',
    owaspReference: 'OWASP LLM01',
    countermeasureImplemented: 'Context-bound system instructions, treating user prompt purely as reflection data, role-separated chat payload.',
    status: 'Enforced',
  },
  {
    zone: 'Tool Execution',
    threatDescription: 'Privilege escalation, SSRF, dynamic code execution risks or unauthorized tool routing.',
    owaspReference: 'OWASP A01 / LLM06',
    countermeasureImplemented: 'Hermetic server-side proxy without dynamic shell calls; scoped REST API endpoints with zero eval/exec.',
    status: 'Enforced',
  },
  {
    zone: 'Memory & State',
    threatDescription: 'Cross-user data leakage in Firestore, unauthorized document reads/writes, session tampering.',
    owaspReference: 'OWASP A01 (Broken Access Control)',
    countermeasureImplemented: 'Strict Firestore security rules: allow read, write: if request.auth.uid == userId; undefined-stripped payloads.',
    status: 'Enforced',
  },
  {
    zone: 'Inter-System Communication',
    threatDescription: 'Gemini API key leakage in browser devtools, client-side secret exposure, transient API outages.',
    owaspReference: 'OWASP A02 (Cryptographic Failures)',
    countermeasureImplemented: 'Zero-hardcoded secrets: GEMINI_API_KEY kept server-only. Resilient 4-step Fallback Ladder for high availability.',
    status: 'Enforced',
  },
];

export const ThreatModelModal: React.FC<ThreatModelModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div 
      id="threat-model-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/60 p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div 
        id="threat-model-dialog"
        className="relative max-h-[90vh] w-full max-w-4xl overflow-hidden rounded-2xl border border-stone-200 bg-stone-50 shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-200 bg-white px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-stone-900">Agentic Threat Model & Security Architecture</h2>
              <p className="text-xs text-stone-700">5 Threat Zones mapped to OWASP Top 10 & LLM Security Safeguards</p>
            </div>
          </div>
          <button
            id="close-threat-modal-btn"
            onClick={onClose}
            className="rounded-lg p-2 text-stone-700 hover:bg-stone-100 transition-colors"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Key Security Guarantees */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="rounded-xl border border-stone-200 bg-white p-4">
              <div className="flex items-center gap-2 text-emerald-800 mb-1">
                <Database className="h-4 w-4" />
                <span className="text-xs font-semibold uppercase tracking-wider">User Isolation</span>
              </div>
              <p className="text-xs text-stone-700">
                Firestore rules strictly enforce <code className="bg-stone-100 px-1 py-0.5 rounded text-stone-800">request.auth.uid == userId</code>. No user can read another's reflections.
              </p>
            </div>
            <div className="rounded-xl border border-stone-200 bg-white p-4">
              <div className="flex items-center gap-2 text-blue-700 mb-1">
                <Cpu className="h-4 w-4" />
                <span className="text-xs font-semibold uppercase tracking-wider">Server-Side AI</span>
              </div>
              <p className="text-xs text-stone-700">
                Gemini API calls are proxied through Node.js Express. API keys are completely concealed from browser clients.
              </p>
            </div>
            <div className="rounded-xl border border-stone-200 bg-white p-4">
              <div className="flex items-center gap-2 text-amber-700 mb-1">
                <Network className="h-4 w-4" />
                <span className="text-xs font-semibold uppercase tracking-wider">Fallback Ladder</span>
              </div>
              <p className="text-xs text-stone-700">
                4-tier model ladder: <code className="bg-stone-100 px-1 py-0.5 rounded text-stone-800">gemini-3.6-flash</code> &rarr; <code className="bg-stone-100 px-1 py-0.5 rounded text-stone-800">3.1-flash-lite</code> &rarr; <code className="bg-stone-100 px-1 py-0.5 rounded text-stone-800">flash-latest</code> &rarr; <code className="bg-stone-100 px-1 py-0.5 rounded text-stone-800">3.7-flash</code>.
              </p>
            </div>
          </div>

          {/* Threat Summary Table */}
          <div className="rounded-xl border border-stone-200 bg-white overflow-hidden shadow-xs">
            <div className="px-4 py-3 bg-stone-100/75 border-b border-stone-200 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-800">Threat Zones & Countermeasure Matrix</span>
              <span className="text-xs font-medium text-emerald-800 flex items-center gap-1">
                <CheckCircle2 className="h-3.5 w-3.5" /> All Countermeasures Active
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-800 font-semibold">
                  <tr>
                    <th className="py-2.5 px-3">Threat Zone</th>
                    <th className="py-2.5 px-3">OWASP / LLM Ref</th>
                    <th className="py-2.5 px-3">Identified Risk</th>
                    <th className="py-2.5 px-3">Active Countermeasure</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-stone-700">
                  {THREAT_MATRIX.map((item) => (
                    <tr key={item.zone} className="hover:bg-stone-50/75">
                      <td className="py-3 px-3 font-semibold text-stone-900 whitespace-nowrap">{item.zone}</td>
                      <td className="py-3 px-3 font-mono text-[11px] text-stone-700 whitespace-nowrap">{item.owaspReference}</td>
                      <td className="py-3 px-3 max-w-xs">{item.threatDescription}</td>
                      <td className="py-3 px-3 max-w-sm text-stone-800">{item.countermeasureImplemented}</td>
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Firestore Security Rules Preview */}
          <div className="rounded-xl border border-stone-200 bg-stone-900 p-4 text-stone-100">
            <div className="flex items-center justify-between pb-2 border-b border-stone-800 mb-3">
              <span className="text-xs font-mono text-stone-400">firestore.rules (Deployed)</span>
              <span className="text-[11px] font-mono text-emerald-400">rules_version = '2'</span>
            </div>
            <pre className="font-mono text-xs leading-relaxed text-stone-300 overflow-x-auto">
{`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/interactions/{interactionId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}`}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-stone-200 bg-white px-6 py-3 flex items-center justify-end">
          <button
            id="dismiss-threat-modal-btn"
            onClick={onClose}
            className="rounded-lg bg-stone-900 px-4 py-2 text-xs font-medium text-white hover:bg-stone-800 transition-colors"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};
