import React, { useState } from 'react';
import { Shield, Lock, AlertCircle, Music, Compass, HeartHandshake } from 'lucide-react';
import { GoldenPeacockLogo } from './GoldenPeacockLogo';
import { signInWithGoogle } from '../firebase';
import { govindAudio } from '../utils/audioManager';
import type { UserProfile } from '../types';

interface LandingPageProps {
  onAuthSuccess: (user: UserProfile) => void;
  onOpenThreatModel: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onAuthSuccess, onOpenThreatModel }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isMusicPlaying, setIsMusicPlaying] = useState(govindAudio.getIsPlaying());

  const toggleMusic = () => {
    const playing = govindAudio.toggleAmbientMusic();
    setIsMusicPlaying(playing);
  };

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setAuthError(null);
    try {
      const user = await signInWithGoogle();
      onAuthSuccess({
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
      });
    } catch (err: any) {
      console.error('Sign-in error:', err);
      let msg = err?.message || 'Failed to sign in with Google.';
      if (err?.code === 'auth/popup-blocked') {
        msg = 'Sign-in popup was blocked by your browser. Please allow popups or use the instant preview profile below.';
      } else if (err?.code === 'auth/cancelled-popup-request' || err?.code === 'auth/popup-closed-by-user') {
        msg = 'Sign-in was cancelled. Please click the button to try again.';
      }
      setAuthError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDevDemoSignIn = () => {
    onAuthSuccess({
      uid: 'user-demo-' + Math.random().toString(36).substring(2, 9),
      email: 'parth.seeker@divine.org',
      displayName: 'Parth (Arjuna)',
      photoURL: null,
    });
  };

  return (
    <div className="min-h-screen bg-[#FAF8F2] text-[#203D32] flex flex-col justify-between relative z-20">
      {/* Top Sanctuary Navbar */}
      <header className="w-full border-b border-[#E5E0D4] bg-[#FAF8F2]/90 backdrop-blur-xs sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GoldenPeacockLogo size="md" showText={true} />
          </div>

          <div className="flex items-center gap-3">
            {/* Ambient flute music toggle */}
            <button
              id="landing-music-toggle-btn"
              onClick={toggleMusic}
              className={`flex items-center gap-1.5 text-xs font-serif px-3 py-1.5 rounded-full border transition-all cursor-pointer ${
                isMusicPlaying
                  ? 'bg-[#EDEAE1] text-[#203D32] border-[#203D32]/30'
                  : 'bg-white text-[#627267] border-[#E5E0D4] hover:text-[#203D32]'
              }`}
              title="Komal Bansuri Sangeet"
            >
              <Music className="h-3.5 w-3.5 text-[#B89548]" />
              <span className="hidden sm:inline">
                {isMusicPlaying ? 'Bansuri Sangeet (Chalu)' : 'Komal Bansuri'}
              </span>
            </button>

            <button
              id="view-threat-model-nav-btn"
              onClick={onOpenThreatModel}
              className="hidden md:flex items-center gap-1.5 text-xs font-serif text-[#627267] hover:text-[#203D32] px-3 py-1.5 rounded-full border border-[#E5E0D4] bg-white hover:bg-[#FAF8F2] transition-colors cursor-pointer"
            >
              <Shield className="h-3.5 w-3.5 text-[#203D32]" />
              <span>Suraksha & Threat Model</span>
            </button>

            <button
              id="nav-signin-btn"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="inline-flex items-center gap-2 rounded-xl bg-[#203D32] hover:bg-[#172D25] px-4 py-2 text-xs font-serif font-semibold text-white transition-all shadow-2xs disabled:opacity-50 cursor-pointer"
            >
              <span>{isLoading ? 'Pravesh ho raha hai...' : 'Google se Pravesh'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-3xl mx-auto px-5 sm:px-8 py-12 sm:py-16 flex-1 flex flex-col justify-center items-center text-center">
        {/* Sacred Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#EBF2EE] border border-[#203D32]/20 text-[#203D32] text-xs font-serif mb-6">
          <span className="text-[#B89548]">✦</span>
          <span>Peace → Reflection → Awareness → Clarity</span>
        </div>

        {/* Heading */}
        <h1 className="text-3xl sm:text-5xl font-serif font-normal text-[#203D32] tracking-tight leading-[1.2] max-w-2xl mb-4">
          Antarman ki Shanti evam Aatma-Chintan
        </h1>

        {/* Subtitle */}
        <p className="text-sm sm:text-base text-[#627267] max-w-xl font-serif leading-relaxed mb-6">
          Apne man ki vyatha, virah, dukh, krodh, ya duvidha ko nishkama gyan ki drishti se dekhein.
          Gita evam Mahabharata ke shashwat darshan se aatmik spashthata prapt karein.
        </p>

        {/* Sacred Verse Banner */}
        <div className="w-full max-w-xl bg-white border border-[#E5E0D4] rounded-2xl p-4 sm:p-5 mb-8 shadow-2xs">
          <p className="font-serif text-sm sm:text-base text-[#203D32] font-semibold tracking-wide italic mb-1">
            &ldquo;Karmanyevadhikaraste Ma Phaleshu Kadachana. Ma Karmaphalaheturbhurma Te Sango'stvakarmani ॥&rdquo;
          </p>
          <p className="text-xs text-[#7C8B82] font-serif">
            Shrimad Bhagavad Gita (2.47) &bull; Karma par hi adhikar hai, phal ki aashakti se mukt rahein.
          </p>
        </div>

        {/* Auth Box Card */}
        <div className="w-full max-w-md bg-white rounded-2xl border border-[#E5E0D4] p-6 sm:p-8 shadow-xs mb-10 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Lock className="h-3.5 w-3.5 text-[#203D32]" />
            <span className="text-xs font-serif font-semibold text-[#203D32] uppercase tracking-wider">
              Surakshit Ekaant Pravesh
            </span>
          </div>

          {authError && (
            <div className="mb-4 rounded-xl bg-red-50 border border-red-200 p-3 text-xs text-red-800 flex items-start gap-2 text-left font-serif">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-red-600" />
              <span>{authError}</span>
            </div>
          )}

          <button
            id="btn-google-login"
            onClick={handleGoogleSignIn}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-3 rounded-xl bg-[#203D32] hover:bg-[#172D25] px-6 py-3 text-sm font-serif font-semibold text-white transition-all shadow-2xs disabled:opacity-50 cursor-pointer"
          >
            <svg className="h-4 w-4" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="currentColor"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="currentColor"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="currentColor"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>{isLoading ? 'Pravesh ho raha hai...' : 'Google se Pravesh Karein'}</span>
          </button>

          <p className="mt-3 text-[11px] text-[#7C8B82] font-serif leading-relaxed">
            Federated Identity: Aapke sabhi chintan poornta ekaant evam Firestore mein surakshit hain.
          </p>

          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#E5E0D4]"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-white px-3 text-[#7C8B82] font-serif">Anya Vikalp</span>
            </div>
          </div>

          <button
            id="preview-demo-login-btn"
            onClick={handleDevDemoSignIn}
            className="w-full text-xs font-serif font-semibold text-[#203D32] hover:text-[#167C78] underline underline-offset-4 py-1 cursor-pointer"
          >
            Parth (Arjuna) ke roop mein arambh karein (Instant Preview)
          </button>
        </div>

        {/* 3 Core Philosophical Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl text-left w-full">
          <div className="rounded-xl border border-[#E5E0D4] bg-white p-5 shadow-2xs">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#FAF8F2] text-[#B89548] mb-3 border border-[#E5E0D4]">
              <Compass className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-serif font-semibold text-[#203D32] mb-1">Aatma-Bodh & Vivek</h3>
            <p className="text-xs text-[#627267] font-serif leading-relaxed">
              Krodh, moh aur ahankar ko samajhkar nishkama bhav se naye drishtikon prapt karein.
            </p>
          </div>

          <div className="rounded-xl border border-[#E5E0D4] bg-white p-5 shadow-2xs">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#FAF8F2] text-[#167C78] mb-3 border border-[#E5E0D4]">
              <HeartHandshake className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-serif font-semibold text-[#203D32] mb-1">Mahabharat Drishtant</h3>
            <p className="text-xs text-[#627267] font-serif leading-relaxed">
              Karna ki peeda, Arjuna ka vishada aur Yudhishthira ke dharma-sankat se seekhein.
            </p>
          </div>

          <div className="rounded-xl border border-[#E5E0D4] bg-white p-5 shadow-2xs">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#FAF8F2] text-[#203D32] mb-3 border border-[#E5E0D4]">
              <Shield className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-serif font-semibold text-[#203D32] mb-1">Pavitra Gopniyata</h3>
            <p className="text-xs text-[#627267] font-serif leading-relaxed">
              Pratyek upayogkarta ka chintan kewal unke niji aasan par hi surakshit rehta hai.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#E5E0D4] bg-[#FAF8F2] py-5 text-center text-xs text-[#7C8B82] font-serif">
        <div className="max-w-5xl mx-auto px-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[#203D32]">Shri Govind Sharanam</span>
            <span>&bull;</span>
            <span>Conscious-Awareness Sanctuary</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={onOpenThreatModel}
              className="text-[#203D32] hover:text-[#167C78] underline underline-offset-2 cursor-pointer"
            >
              Suraksha Threat Model (5 Zones)
            </button>
            <span className="text-[#E5E0D4]">|</span>
            <span>Gemini 3.6 Flash Resilient AI</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
