import React, { useEffect, useRef } from 'react';

interface Petal {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  rotation: number;
  rotationSpeed: number;
  flip: number;
  flipSpeed: number;
  colorType: 'lotus' | 'parijat' | 'champa' | 'pollen';
  opacity: number;
}

export const AestheticGardenBackground: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Generate 3D floating flower petals & glowing pollen
    const PETAL_COUNT = 38;
    const petals: Petal[] = [];

    const types: Array<'lotus' | 'parijat' | 'champa' | 'pollen'> = ['lotus', 'lotus', 'parijat', 'champa', 'pollen'];

    for (let i = 0; i < PETAL_COUNT; i++) {
      petals.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 14 + 8,
        speedY: Math.random() * 0.75 + 0.35,
        speedX: Math.random() * 0.6 - 0.3,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.02,
        flip: Math.random() * Math.PI,
        flipSpeed: Math.random() * 0.03 + 0.01,
        colorType: types[Math.floor(Math.random() * types.length)],
        opacity: Math.random() * 0.65 + 0.3,
      });
    }

    let time = 0;

    const render = () => {
      time += 0.015;
      ctx.clearRect(0, 0, width, height);

      petals.forEach((p) => {
        // Update physics with 3D fluttering & wind drift
        p.y += p.speedY;
        p.x += p.speedX + Math.sin(time + p.y * 0.01) * 0.45;
        p.rotation += p.rotationSpeed;
        p.flip += p.flipSpeed;

        // Wrap around viewport
        if (p.y > height + 20) {
          p.y = -20;
          p.x = Math.random() * width;
        }
        if (p.x < -30) p.x = width + 20;
        if (p.x > width + 30) p.x = -20;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);

        // 3D pitch/flip transformation simulation
        const scaleY = Math.cos(p.flip);
        ctx.scale(1, scaleY);
        ctx.globalAlpha = p.opacity;

        if (p.colorType === 'pollen') {
          // Luminous golden pollen spark
          const rad = p.size * 0.25;
          const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, rad * 3);
          grad.addColorStop(0, 'rgba(255, 236, 179, 0.9)');
          grad.addColorStop(0.5, 'rgba(255, 213, 79, 0.4)');
          grad.addColorStop(1, 'rgba(255, 213, 79, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(0, 0, rad * 3, 0, Math.PI * 2);
          ctx.fill();
        } else {
          // 2D/3D Floral Petal Drawing
          ctx.beginPath();
          // Organic curved petal geometry
          ctx.moveTo(0, -p.size);
          ctx.bezierCurveTo(p.size * 0.7, -p.size * 0.6, p.size * 0.8, p.size * 0.4, 0, p.size);
          ctx.bezierCurveTo(-p.size * 0.8, p.size * 0.4, -p.size * 0.7, -p.size * 0.6, 0, -p.size);

          if (p.colorType === 'lotus') {
            // Sacred Pink Lotus Petal
            const grad = ctx.createLinearGradient(0, -p.size, 0, p.size);
            grad.addColorStop(0, '#fda4af');
            grad.addColorStop(0.6, '#f43f5e');
            grad.addColorStop(1, '#ffffff');
            ctx.fillStyle = grad;
          } else if (p.colorType === 'parijat') {
            // Sacred Parijat (white petal with orange stem accent)
            const grad = ctx.createLinearGradient(0, -p.size, 0, p.size);
            grad.addColorStop(0, '#ffffff');
            grad.addColorStop(0.7, '#fff7ed');
            grad.addColorStop(1, '#ea580c');
            ctx.fillStyle = grad;
          } else {
            // Golden Champa / Kadamba Petal
            const grad = ctx.createLinearGradient(0, -p.size, 0, p.size);
            grad.addColorStop(0, '#fef08a');
            grad.addColorStop(0.6, '#f59e0b');
            grad.addColorStop(1, '#ffffff');
            ctx.fillStyle = grad;
          }

          ctx.fill();

          // Subtle central petal vein
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
          ctx.lineWidth = 0.75;
          ctx.beginPath();
          ctx.moveTo(0, -p.size * 0.7);
          ctx.lineTo(0, p.size * 0.6);
          ctx.stroke();
        }

        ctx.restore();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-[#eef4f0]">
      {/* 2D/3D Vrindavan Aesthetic Garden High-Res Background Image */}
      <div
        className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000"
        style={{
          backgroundImage: `url('/src/assets/images/vrindavan_aesthetic_garden_1788637956307.jpg')`,
          filter: 'saturate(1.08) brightness(0.97)',
        }}
      />

      {/* Aesthetic garden ambient light & subtle veil to ensure supreme readability */}
      <div className="fixed inset-0 pointer-events-none z-0 bg-gradient-to-b from-[#f4f8f5]/82 via-[#edf4ef]/75 to-[#e6efe8]/86 backdrop-blur-[1.5px]" />

      {/* Floating 2D/3D Flower Petals & Luminous Pollen Canvas */}
      <canvas
        ref={canvasRef}
        className="fixed inset-0 pointer-events-none z-[1]"
        style={{ opacity: 0.88 }}
      />

      {/* Content wrapper */}
      <div className="relative z-10">{children}</div>
    </div>
  );
};
