import React, { useState } from 'react';
import { 
  PlusCircle, 
  Search, 
  MessageSquare, 
  Sparkles, 
  Lightbulb, 
  FileText, 
  Trash2, 
  Clock,
  Filter
} from 'lucide-react';
import type { JournalInteraction, ReflectionMode } from '../types';

interface HistorySidebarProps {
  interactions: JournalInteraction[];
  activeInteractionId: string | null;
  onSelectInteraction: (id: string) => void;
  onNewReflection: () => void;
  onDeleteInteraction: (id: string) => void;
  isLoading: boolean;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const HistorySidebar: React.FC<HistorySidebarProps> = ({
  interactions,
  activeInteractionId,
  onSelectInteraction,
  onNewReflection,
  onDeleteInteraction,
  isLoading,
  isOpenMobile,
  onCloseMobile,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | ReflectionMode>('all');

  // Filter interactions
  const filteredInteractions = interactions.filter((item) => {
    const matchesFilter = selectedFilter === 'all' || item.reflectionType === selectedFilter;
    const term = searchTerm.toLowerCase();
    const matchesSearch = 
      !searchTerm ||
      item.title?.toLowerCase().includes(term) ||
      item.summary?.toLowerCase().includes(term) ||
      item.messages.some((m) => m.content.toLowerCase().includes(term));
    return matchesFilter && matchesSearch;
  });

  const getModeIcon = (mode: ReflectionMode) => {
    switch (mode) {
      case 'brainstorm':
        return <Lightbulb className="h-3 w-3 text-[#B89548]" />;
      case 'summary':
        return <FileText className="h-3 w-3 text-[#167C78]" />;
      case 'deep-reflection':
        return <Sparkles className="h-3 w-3 text-[#7A5824]" />;
      default:
        return <MessageSquare className="h-3 w-3 text-[#203D32]" />;
    }
  };

  const getModeLabel = (mode: ReflectionMode) => {
    switch (mode) {
      case 'brainstorm':
        return 'Drishtikon';
      case 'summary':
        return 'Saar';
      case 'deep-reflection':
        return 'Aatma-Bodh';
      default:
        return 'Margdarshan';
    }
  };

  const formatDate = (isoString?: string) => {
    if (!isoString) return '';
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
    } catch {
      return '';
    }
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Kya aap is chintan ko hatana chahte hain?')) {
      onDeleteInteraction(id);
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div 
          className="fixed inset-0 bg-[#203D32]/20 z-30 md:hidden backdrop-blur-xs"
          onClick={onCloseMobile}
        />
      )}

      <aside
        id="history-sidebar"
        className={`
          fixed md:static inset-y-0 left-0 z-40 w-80 shrink-0 bg-[#FAF8F2] border-r border-[#E5E0D4] flex flex-col transition-transform duration-200 ease-in-out
          ${isOpenMobile ? 'translate-x-0 shadow-lg' : '-translate-x-full md:translate-x-0'}
        `}
      >
        {/* Sidebar Header & New Reflection Button */}
        <div className="p-4 border-b border-[#E5E0D4] bg-[#FAF8F2]">
          <button
            id="new-reflection-btn"
            onClick={() => {
              onNewReflection();
              onCloseMobile();
            }}
            className="w-full flex flex-col items-center justify-center py-2.5 px-4 rounded-xl bg-[#203D32] hover:bg-[#172D25] text-white transition-all cursor-pointer shadow-xs group"
          >
            <span className="font-serif text-sm font-semibold tracking-wide flex items-center gap-1.5 text-[#F2ECE1]">
              <PlusCircle className="h-3.5 w-3.5 text-[#B89548]" />
              <span>+ Naveen Chintan</span>
            </span>
            <span className="text-[10px] text-[#A3B3A9] font-sans tracking-wide">
              New Reflection
            </span>
          </button>

          {/* Search bar */}
          <div className="mt-3 relative">
            <Search className="h-3.5 w-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#7C8B82]" />
            <input
              id="history-search-input"
              type="text"
              placeholder="Chintan khojein..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-[#E5E0D4] bg-white focus:outline-none focus:border-[#203D32] text-[#203D32] placeholder-[#A2ADA7] font-serif transition-colors"
            />
          </div>

          {/* Simple filter / navigation row */}
          <div className="flex items-center gap-1.5 mt-2.5 overflow-x-auto pb-0.5 text-[11px] font-serif">
            <button
              onClick={() => setSelectedFilter('all')}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                selectedFilter === 'all'
                  ? 'bg-[#203D32] text-white font-medium shadow-2xs'
                  : 'bg-transparent text-[#627267] hover:text-[#203D32] hover:bg-[#EDEAE1]'
              }`}
            >
              Sabhi ({interactions.length})
            </button>
            <button
              onClick={() => setSelectedFilter('reflection')}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                selectedFilter === 'reflection'
                  ? 'bg-[#203D32] text-white font-medium shadow-2xs'
                  : 'bg-transparent text-[#627267] hover:text-[#203D32] hover:bg-[#EDEAE1]'
              }`}
            >
              Margdarshan
            </button>
            <button
              onClick={() => setSelectedFilter('brainstorm')}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                selectedFilter === 'brainstorm'
                  ? 'bg-[#203D32] text-white font-medium shadow-2xs'
                  : 'bg-transparent text-[#627267] hover:text-[#203D32] hover:bg-[#EDEAE1]'
              }`}
            >
              Drishtikon
            </button>
            <button
              onClick={() => setSelectedFilter('summary')}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                selectedFilter === 'summary'
                  ? 'bg-[#203D32] text-white font-medium shadow-2xs'
                  : 'bg-transparent text-[#627267] hover:text-[#203D32] hover:bg-[#EDEAE1]'
              }`}
            >
              Saar
            </button>
          </div>
        </div>

        {/* History List: Private Journal Index */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
          {isLoading && interactions.length === 0 ? (
            <div className="p-8 text-center text-xs text-[#627267]">
              <div className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-[#E5E0D4] border-t-[#203D32] mb-2"></div>
              <p className="font-serif">Chintan soochi aahvaan ho rahi hai...</p>
            </div>
          ) : filteredInteractions.length === 0 ? (
            <div className="p-6 text-center text-xs text-[#7C8B82] font-serif">
              <MessageSquare className="h-5 w-5 mx-auto text-[#DCD7C9] mb-2" />
              <p className="font-medium text-[#203D32]">
                {searchTerm ? 'Koi mel khata chintan nahi mila' : 'Abhi koi poorva chintan nahi hai'}
              </p>
              <p className="mt-1 text-[11px] text-[#7C8B82]">
                {searchTerm ? 'Anya shabd khojein' : '+ Naveen Chintan se arambh karein'}
              </p>
            </div>
          ) : (
            filteredInteractions.map((item) => {
              const isActive = item.id === activeInteractionId;
              const lastMsg = item.messages[item.messages.length - 1];
              const preview = item.summary || lastMsg?.content || 'Naveen chintan satr';

              return (
                <div
                  key={item.id}
                  id={`history-item-${item.id}`}
                  onClick={() => {
                    onSelectInteraction(item.id);
                    onCloseMobile();
                  }}
                  className={`
                    group relative rounded-xl p-3 text-left transition-all cursor-pointer border
                    ${
                      isActive
                        ? 'bg-[#EBF2EE] border-[#203D32]/25 shadow-2xs'
                        : 'bg-white border-[#E5E0D4] hover:bg-[#F5F3ED] hover:border-[#DCD7C9]'
                    }
                  `}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="font-serif font-semibold text-xs text-[#203D32] line-clamp-1">
                      {item.title || 'Naveen Chintan'}
                    </span>
                    <button
                      id={`delete-entry-${item.id}`}
                      onClick={(e) => handleDelete(e, item.id)}
                      title="Chintan hatayein"
                      className="opacity-0 group-hover:opacity-100 p-1 text-[#7C8B82] hover:text-red-700 hover:bg-red-50 rounded transition-opacity cursor-pointer"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>

                  <p className="text-[11px] text-[#627267] line-clamp-2 leading-relaxed mb-2 font-serif">
                    {preview}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-[#7C8B82] font-serif">
                    <span className="flex items-center gap-1">
                      {getModeIcon(item.reflectionType)}
                      <span className="text-[#203D32] font-medium">{getModeLabel(item.reflectionType)}</span>
                    </span>
                    <span>{formatDate(item.updatedAt || item.createdAt)}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info: Quiet and minimalist */}
        <div className="p-3 border-t border-[#E5E0D4] bg-[#FAF8F2] text-center">
          <p className="text-[10px] text-[#7C8B82] font-serif">
            Gopniya Ekaant • Firestore Surakshit
          </p>
        </div>
      </aside>
    </>
  );
};
