import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut as firebaseSignOut, 
  onAuthStateChanged, 
  User 
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  getDoc, 
  getDocFromServer,
  deleteDoc, 
  query, 
  orderBy, 
  serverTimestamp,
  Firestore
} from 'firebase/firestore';
import type { JournalInteraction, UserProfile } from './types';
import appletConfig from '../firebase-applet-config.json';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(appletConfig) : getApp();

// Initialize Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Initialize Firestore with specific databaseId if provided in config
export const db: Firestore = appletConfig.firestoreDatabaseId
  ? getFirestore(app, appletConfig.firestoreDatabaseId)
  : getFirestore(app);

// Test initial connection to Firestore as required by Firebase specification
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
testConnection();

/**
 * Strict Undefined-Stripping (Zero-Crash Payload Hygiene)
 * Strips all undefined values recursively before passing payload to Firestore SDK.
 */
export function stripUndefined<T>(obj: T): T {
  if (obj === null || obj === undefined) {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj.map((item) => stripUndefined(item)) as unknown as T;
  }
  if (typeof obj === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        cleaned[key] = stripUndefined(value);
      }
    }
    return cleaned as T;
  }
  return obj;
}

/**
 * Sign In with Google via Firebase Auth
 */
export async function signInWithGoogle(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

/**
 * Sign Out
 */
export async function signOut(): Promise<void> {
  await firebaseSignOut(auth);
}

/**
 * Firestore CRUD helpers enforcing strict user data isolation
 * Path: /users/{userId}/interactions/{interactionId}
 */
export function getUserInteractionsCollection(userId: string) {
  if (!userId) throw new Error('Cannot access interactions: Missing userId');
  return collection(db, 'users', userId, 'interactions');
}

/**
 * Save or update an interaction in Firestore
 * Enforces transaction verification and undefined-stripping
 */
export async function saveUserInteraction(interaction: JournalInteraction): Promise<void> {
  if (!interaction.userId) {
    throw new Error('User authentication required to persist journal interactions.');
  }

  const docRef = doc(db, 'users', interaction.userId, 'interactions', interaction.id);
  const sanitizedPayload = stripUndefined({
    ...interaction,
    savedAt: new Date().toISOString(),
    _dbTimestamp: serverTimestamp(),
  });

  await setDoc(docRef, sanitizedPayload, { merge: true });
}

/**
 * Fetch all journal interactions for the authenticated user, ordered by updatedAt desc
 */
export async function fetchUserInteractions(userId: string): Promise<JournalInteraction[]> {
  if (!userId) return [];

  const interactionsRef = getUserInteractionsCollection(userId);
  try {
    const q = query(interactionsRef, orderBy('updatedAt', 'desc'));
    const snapshot = await getDocs(q);
    const results: JournalInteraction[] = [];
    snapshot.forEach((d) => {
      const data = d.data() as JournalInteraction;
      results.push(data);
    });
    return results;
  } catch (err) {
    console.warn('Query with orderBy failed, falling back to unordered fetch:', err);
    const snapshot = await getDocs(interactionsRef);
    const results: JournalInteraction[] = [];
    snapshot.forEach((d) => {
      const data = d.data() as JournalInteraction;
      results.push(data);
    });
    return results.sort(
      (a, b) => new Date(b.updatedAt || 0).getTime() - new Date(a.updatedAt || 0).getTime()
    );
  }
}

/**
 * Delete a user interaction document
 */
export async function deleteUserInteraction(userId: string, interactionId: string): Promise<void> {
  if (!userId || !interactionId) return;
  const docRef = doc(db, 'users', userId, 'interactions', interactionId);
  await deleteDoc(docRef);
}
