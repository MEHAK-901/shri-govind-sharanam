import { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, signOut as firebaseSignOut } from './firebase';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';
import { ThreatModelModal } from './components/ThreatModelModal';
import { AestheticGardenBackground } from './components/AestheticGardenBackground';
import type { UserProfile } from './types';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isAuthInitializing, setIsAuthInitializing] = useState(true);
  const [isThreatModalOpen, setIsThreatModalOpen] = useState(false);

  useEffect(() => {
    // Listen for Firebase Auth state transitions
    const unsubscribe = onAuthStateChanged(auth, (user: User | null) => {
      if (user) {
        setCurrentUser({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
        });
      } else {
        // Only clear if not in an active sandbox session
        setCurrentUser((prev) => (prev?.uid.startsWith('user-demo-') ? prev : null));
      }
      setIsAuthInitializing(false);
    });

    return () => unsubscribe();
  }, []);

  const handleSignOut = async () => {
    try {
      await firebaseSignOut();
    } catch (err) {
      console.warn('Firebase signout warning:', err);
    }
    setCurrentUser(null);
  };

  // Loading splash while checking auth
  if (isAuthInitializing) {
    return (
      <div className="min-h-screen w-screen bg-gradient-to-br from-[#fdfbf7] via-[#edf7f2] to-[#f7f0eb] flex flex-col items-center justify-center text-[#1e2922]">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#2d5a43] text-amber-200 shadow-lg mb-4 animate-pulse text-2xl">
          🦚
        </div>
        <p className="font-serif text-lg font-bold text-[#1e3d2d]">Shri Govind Sarthi</p>
        <p className="text-xs text-[#5c6f64] mt-1 font-serif">Pavitra upavan evam satr satyapana...</p>
      </div>
    );
  }

  return (
    <AestheticGardenBackground>
      {currentUser ? (
        <Dashboard
          user={currentUser}
          onSignOut={handleSignOut}
          onOpenThreatModel={() => setIsThreatModalOpen(true)}
        />
      ) : (
        <LandingPage
          onAuthSuccess={(user) => setCurrentUser(user)}
          onOpenThreatModel={() => setIsThreatModalOpen(true)}
        />
      )}

      {/* Global Threat Model & Security Modal */}
      <ThreatModelModal
        isOpen={isThreatModalOpen}
        onClose={() => setIsThreatModalOpen(false)}
      />
    </AestheticGardenBackground>
  );
}
