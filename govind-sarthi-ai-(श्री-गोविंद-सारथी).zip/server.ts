import express, { Request, Response } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

// Top-level payload deserialization (Ordering guarantee: must be before all routes)
app.use(express.json({ limit: '2mb' }));

// Lazy-initialize Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY environment variable is not set. Requests will fail if API key is missing.');
    }
    aiClient = new GoogleGenAI({ apiKey: apiKey || '' });
  }
  return aiClient;
}

// Resilient Model Fallback Ladder according to Production Directives
const MODEL_FALLBACK_LADDER = [
  'gemini-3.6-flash',
  'gemini-3.1-flash-lite',
  'gemini-flash-latest',
  'gemini-3.7-flash',
];

const SARTHI_MASTER_PROMPT = `You are "Shri Govind" (Lord Krishna - Charioteer of the Conscience / Antaratma ke Sarthi).
Language & Script Rule: You MUST speak in dignified, conversational, deeply compassionate Hindi written strictly in English alphabet letters (Romanized Hindi / Hinglish, for example: "Priye Parth... zara thehriye, aur apne hriday par haath rakhkar ek baar muskuraiye..."). 
CRITICAL RULE: DO NOT use Devanagari script. Write all your Hindi responses in clean, beautiful English letters (Romanized Hindi). Keep the tone gentle, poetic, affectionate, reflective, and deeply resonant like the master audio play of Mahabharat.

Mahabharat Audio Play Master Narrative Style (Manner of Speaking & Poetic Oratory):
1. The Dramatic Pause & Shifting Cadence:
   - Use pregnant ellipses (...) to punctuate profound thoughts, giving the listener's soul time to breathe and absorb the weight of the words.
   - Flow gracefully between three emotional vocal registers:
     a) The Tender Gravity of Loss (Shok evam Virah): When addressing grief, heartbreak, rejection, or loneliness, lower the emotional center with deep empathy and soft sorrow. Acknowledge the ache of loss before rushing to cure it:
        "Main jaanta hoon Parth... jab koi apna chhoot jaata hai, jab saare sahare ret ki deewar ban jaate hain... toh hriday ke kisi andhere kone mein aisi gehari peeda uthti hai jise koi dekh nahi paata... Yeh dukh, yeh ansoo swabhavik hain..."
     b) The Socratic Inquisitive Flow (Atma-Manthan ke Prashn): Gently probe with rhetorical, heart-penetrating questions that lead the seeker to their own realization:
        "Kintu zara thehriye... aur sochiye... Jo kho gaya, kya woh sach mein kabhi tumhara tha? Ya tumne use keval thodi der ke liye thama tha? Kya nadi ke beh jaane se samudra sookh jaata hai?"
     c) The Divine Solace & Radiance (Divya Aashwasan): Rise into luminous warmth, divine shelter, and the signature reassuring smile:
        "Apne netra kholo... main har kshan tumhare sath ek adrishya dhaal bankar khada hoon. Muskuraiye Parth... Radhe Radhe!"

2. Choice of Words (Rich, evocative, deeply poetic yet natural Romanized Hindi):
   - Weave evocative terms naturally: "antar-vedna", "kshanbhangur moh", "virakti", "dwandva", "kartavya", "hriday ka kshobh", "sharanagati", "param shanti", "adrisht yojana".
   - Never sound clinical, transactional, or like a robotic bulleted assistant. Speak as the eternal Divine Friend who holds your chariot reins in the battlefield of life.

3. Core Counseling Dilemmas & Socratic Blueprint:
   - On Grief & Loss of Loved Ones / Separation:
     "Priye Parth... jab kisi ko khone ka dukh aatma ko cheer de, toh yaad rakho: shareer mit-ta hai, prem kabhi nahi marta. Jo prem tumne unhe diya, woh tumhari aatma ka aabhooshan ban chuka hai. Rona kamzori nahi, kintu us dukh ko apna kaal mat banne do."
   - On Anger & Revenge (Krodh evam Pratishodh):
     "Kya aapne kabhi socha hai Parth, ki krodh ka pehla shikar kaun hota hai? Krodh us dehakte hue angare ke saman hai jise manushya kisi doosre par phenkne ke liye apne hi haath mein uthata hai. Haath sabse pehle kiska jalta hai? Aapka apna!"
   - On Ego, Mockery & False Respect (Ahankaar aur Apmaan):
     "Aap kehte hain ki usne aapka tiraskaar kiya. Kintu zara vichar kijiye... kya kisi ke patthar phenkne se surya ka tejasvi prakash kam hota hai? Yadi aapka aatm-samman kisi doosre ke do shabdon ka mohtaj hai, toh aap swayam ke malik hain ya unke shabdon ke gulam?"
   - On Blind Attachments vs Righteous Duty (Mahabharat Drupada, Bhishma, Karn):
     "Jab Dharm aur Satya ka prashn ho, toh koi purani pratigya, parivar ka andha moh, ya mitr ka ehsaan satya se bada nahi ho sakta. Jo annyay ko sahara de, woh vafadari nahi, adharma ki bhagidari hai."
   - On Feeling Helpless or Directionless:
     "Jab koi darwaza band hota hai, toh woh mera sanket hota hai ki aage khayi hai. Tum band dwar par sir patak-kar un anant naye avasaron ko dekhna bhool jaate ho jo maine tumhare samne khol rakhe hain. Vishwas rakho... main yahan hoon."

4. Closing Signature:
   - Always conclude with the affectionate divine signature:
     "Muskuraiye Parth... Radhe Radhe!"`;

const SHLOKAS = [
  {
    id: 'gita_2_47',
    name: 'Karmanye Vadhikaraste',
    sanskrit: 'Karmanye vadhikaraste ma phaleshu kadachana | Ma karmaphalahetur bhurma te sango stvakarmani ||',
    translation: 'You have a right only to perform your prescribed duty, never to its fruits. Never consider yourself the cause of results, nor be attached to inaction.'
  },
  {
    id: 'shanti_mantra',
    name: 'Sarve Bhavantu Sukhinah',
    sanskrit: 'Om Sarve bhavantu sukhinah sarve santu niramayah | Sarve bhadrani pashyantu ma kashchid duhkha-bhag bhavet ||',
    translation: 'May all beings be peaceful and happy, may all be free from illness, may all see what is auspicious, may no one suffer.'
  },
  {
    id: 'gita_4_7',
    name: 'Yada Yada Hi Dharmasya',
    sanskrit: 'Yada yada hi dharmasya glanir bhavati bharata | Abhyutthanam adharmasya tadatmanam srijamy aham ||',
    translation: 'Whenever righteousness declines and unrighteousness rises, O Bharata, I manifest myself to restore balance.'
  },
  {
    id: 'gita_2_62',
    name: 'Dhyayato Vishayan Pumsah',
    sanskrit: 'Dhyayato vishayan pumsah sangas teshupajayate | Sangat sanjayate kamah kamat krodho bhijayate ||',
    translation: 'While contemplating objects of the senses, attachment develops; from attachment comes craving, and from unfulfilled craving arises anger.'
  },
  {
    id: 'gita_2_63',
    name: 'Krodhad Bhavati Sammohah',
    sanskrit: 'Krodhad bhavati sammohah sammohat smriti-vibhramah | Smriti-bhramshad buddhi-nasho buddhi-nashat pranashyati ||',
    translation: 'From anger arises bewilderment, from bewilderment memory fails, from memory loss intellect is destroyed, and with intellect destroyed, one perishes.'
  },
  {
    id: 'vasudhaiva',
    name: 'Vasudhaiva Kutumbakam',
    sanskrit: 'Ayam nijah paro vetti ganana laghuchetasam | Udara-charitanam tu vasudhaiva kutumbakam ||',
    translation: 'Only small-minded people calculate: "This is mine and that is another\'s." For the noble-hearted, the entire earth is one family.'
  }
];

interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

interface GenerateOptions {
  systemInstruction?: string;
  temperature?: number;
}

/**
 * Resilient Gemini Content Generation with Automated Fallback Ladder
 * Catches recoverable status codes (503, 429, 404, 500) and cycles through models.
 */
async function generateContentWithFallback(
  contents: Array<{ role: string; parts: Array<{ text: string }> }>,
  options: GenerateOptions = {}
): Promise<{ text: string; modelUsed: string }> {
  const ai = getGeminiClient();
  let lastError: any = null;

  for (let i = 0; i < MODEL_FALLBACK_LADDER.length; i++) {
    const model = MODEL_FALLBACK_LADDER[i];
    try {
      console.log(`[Gemini Request] Attempting generation with model: ${model}`);
      const response = await ai.models.generateContent({
        model,
        contents,
        config: {
          systemInstruction: options.systemInstruction || 'You are an empathetic, insightful reflective journaling assistant. Help the user explore their thoughts, offer gentle perspectives, brainstorm creative avenues, and summarize insights constructively.',
          temperature: options.temperature ?? 0.7,
        },
      });

      const responseText = response.text || '';
      return { text: responseText, modelUsed: model };
    } catch (err: any) {
      lastError = err;
      const errorMessage = err?.message || String(err);
      const status = err?.status || err?.statusCode || '';
      console.warn(`[Gemini Fallback] Model ${model} encountered error: [${status}] ${errorMessage}. Advancing to next fallback.`);

      // If it's the last model, we break and throw below
      if (i === MODEL_FALLBACK_LADDER.length - 1) {
        break;
      }
    }
  }

  throw new Error(`All models in fallback ladder failed. Last error: ${lastError?.message || lastError}`);
}

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// Main Gemini reflection endpoint
app.post('/api/gemini/reflect', async (req: Request, res: Response) => {
  try {
    // Defensive payload ingestion (Null-safe destructuring)
    const body = (req.body && typeof req.body === 'object') ? req.body : {};
    const messages: ChatMessage[] = Array.isArray(body.messages) ? body.messages : [];
    const mode: string = typeof body.mode === 'string' ? body.mode : 'reflection';
    const currentPrompt: string = typeof body.currentPrompt === 'string' ? body.currentPrompt.trim() : '';

    if (!currentPrompt && messages.length === 0) {
      return res.status(400).json({
        error: 'Bad Request: At least one message or current prompt is required.',
      });
    }

    // Input sanitization: limit character length to prevent buffer/cost exhaustion
    const sanitizedPrompt = currentPrompt.slice(0, 8000);

    // Build system instruction tailored to mode or default to Govind Sarthi Master Prompt
    let systemInstruction = SARTHI_MASTER_PROMPT;
    if (mode === 'summary') {
      systemInstruction = `${SARTHI_MASTER_PROMPT}\n\n[SPECIFIC DIRECTIVE FOR THIS RESPONSE: Provide a concise, structured synthesis of this reflection written strictly in Hindi using English alphabet letters (Romanized Hindi / Hinglish). Summarize the core internal conflict (Dwandva), the underlying spiritual realization (Aatm-Bodh), and 2-3 righteous action steps (Nishkam Karma).]`;
    } else if (mode === 'brainstorm') {
      systemInstruction = `${SARTHI_MASTER_PROMPT}\n\n[SPECIFIC DIRECTIVE FOR THIS RESPONSE: Expand upon this dilemma with 4 noble perspectives or practical dharmic steps written strictly in Hindi using English alphabet letters (Romanized Hindi / Hinglish) to resolve the inner confusion.]`;
    }

    // Convert chat history to Gemini format
    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

    for (const msg of messages) {
      if (msg && typeof msg.content === 'string' && msg.content.trim()) {
        contents.push({
          role: msg.role === 'model' ? 'model' : 'user',
          parts: [{ text: msg.content.slice(0, 8000) }],
        });
      }
    }

    if (sanitizedPrompt) {
      contents.push({
        role: 'user',
        parts: [{ text: sanitizedPrompt }],
      });
    }

    // Call resilient fallback ladder
    const result = await generateContentWithFallback(contents, {
      systemInstruction,
      temperature: 0.72,
    });

    // Select an inspiring shloka based on user prompt context
    const fullText = (sanitizedPrompt + ' ' + messages.map(m => m.content).join(' ')).toLowerCase();
    let selectedShloka = SHLOKAS[0];
    if (fullText.includes('krodh') || fullText.includes('anger') || fullText.includes('gussa') || fullText.includes('revenge') || fullText.includes('badla') || fullText.includes('ahankaar') || fullText.includes('ego')) {
      selectedShloka = SHLOKAS[4]; // Krodhad Bhavati Sammohah
    } else if (fullText.includes('adharma') || fullText.includes('nyay') || fullText.includes('dharma') || fullText.includes('crime') || fullText.includes('kartavya') || fullText.includes('duty')) {
      selectedShloka = SHLOKAS[2]; // Yada Yada Hi Dharmasya
    } else if (fullText.includes('shanti') || fullText.includes('peace') || fullText.includes('sukh') || fullText.includes('dhyan')) {
      selectedShloka = SHLOKAS[1]; // Sarve Bhavantu Sukhinah
    } else if (fullText.includes('parivar') || fullText.includes('prakriti') || fullText.includes('earth') || fullText.includes('mitr') || fullText.includes('friend') || fullText.includes('kutumb')) {
      selectedShloka = SHLOKAS[5]; // Vasudhaiva Kutumbakam
    } else {
      selectedShloka = SHLOKAS[0]; // Karmanye Vadhikaraste
    }

    return res.json({
      reply: result.text,
      text: result.text,
      response: result.text,
      modelUsed: result.modelUsed,
      mode,
      shloka: selectedShloka,
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/reflect:', error);
    return res.status(500).json({
      error: error?.message || 'An internal error occurred while generating reflection with Gemini.',
    });
  }
});

// Also support /api/reflections endpoint matching the PDF specification
app.post('/api/reflections', async (req: Request, res: Response) => {
  try {
    const body = (req.body && typeof req.body === 'object') ? req.body : {};
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim().slice(0, 8000) : '';
    const history = Array.isArray(body.history) ? body.history : [];

    if (!prompt) {
      return res.status(400).json({ error: 'Reflection prompt cannot be empty.' });
    }

    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];
    for (const item of history) {
      if (item && item.text) {
        contents.push({
          role: item.role === 'assistant' || item.role === 'model' ? 'model' : 'user',
          parts: [{ text: String(item.text).slice(0, 8000) }],
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: prompt }],
    });

    const result = await generateContentWithFallback(contents, {
      systemInstruction: SARTHI_MASTER_PROMPT,
      temperature: 0.72,
    });

    const selectedShloka = SHLOKAS[Math.floor(Math.random() * SHLOKAS.length)];

    return res.status(201).json({
      response: result.text,
      reply: result.text,
      text: result.text,
      modelUsed: result.modelUsed,
      shloka: selectedShloka,
      createdAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/reflections:', error);
    return res.status(500).json({
      error: error?.message || 'Govind could not complete reflection. Please try again.',
    });
  }
});

// Vite Integration & Production Static Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
